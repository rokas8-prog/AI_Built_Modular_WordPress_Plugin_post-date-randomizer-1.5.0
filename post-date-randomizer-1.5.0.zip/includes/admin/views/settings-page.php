<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>
<div class="wrap">
    <h1><?php esc_html_e( 'Post Date Randomizer', 'post-date-randomizer' ); ?></h1>

    <?php require plugin_dir_path( __FILE__ ) . 'sections/section-settings.php'; ?>

    <hr />

    <?php require plugin_dir_path( __FILE__ ) . 'sections/section-run.php'; ?>
</div>
