<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>
<h2><?php esc_html_e( 'Run randomizer', 'post-date-randomizer' ); ?></h2>
<p>
    <?php esc_html_e( 'The options saved above will be used. Make a database backup before running this action.', 'post-date-randomizer' ); ?>
</p>
<form method="post">
    <?php wp_nonce_field( 'pdr_run_randomize_action', 'pdr_run_nonce' ); ?>
    <?php submit_button( __( 'Randomize dates now', 'post-date-randomizer' ), 'secondary', 'pdr_run_randomize' ); ?>
</form>
