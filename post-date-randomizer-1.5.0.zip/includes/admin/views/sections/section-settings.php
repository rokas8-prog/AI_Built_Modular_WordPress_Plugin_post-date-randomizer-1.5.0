<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>
<h2><?php esc_html_e( 'Settings', 'post-date-randomizer' ); ?></h2>
<form method="post" action="options.php">
    <?php
    settings_fields( self::OPTION_GROUP );
    do_settings_sections( self::SETTINGS_PAGE );
    submit_button( __( 'Save settings', 'post-date-randomizer' ) );
    ?>
</form>
