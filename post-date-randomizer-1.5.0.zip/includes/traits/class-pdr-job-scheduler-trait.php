<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait PDR_Job_Scheduler_Trait {

    protected function get_job_lock_timeout() {
        return MINUTE_IN_SECONDS;
    }

    protected function get_job_lock_transient_key( $token ) {
        return PDR_Key_Utils::job_lock_key( $token );
    }

    protected function get_job_lock_option_key( $token ) {
        return $this->get_job_lock_transient_key( $token );
    }

    protected function get_randomizer_job_lock_payload( $token ) {
        $now = time();

        return array(
            'token'      => sanitize_key( (string) $token ),
            'created_at' => $now,
            'expires_at' => $now + (int) $this->get_job_lock_timeout(),
        );
    }

    protected function is_randomizer_job_lock_expired( $lock ) {
        if ( ! is_array( $lock ) || empty( $lock['expires_at'] ) ) {
            return true;
        }

        return ( (int) $lock['expires_at'] < time() );
    }

    protected function update_randomizer_job_lock_option( $option_key, $existing_lock, $new_lock ) {
        global $wpdb;

        $updated = $wpdb->update(
            $wpdb->options,
            array(
                'option_value' => maybe_serialize( $new_lock ),
                'autoload'     => 'no',
            ),
            array(
                'option_name'  => $option_key,
                'option_value' => maybe_serialize( $existing_lock ),
            ),
            array( '%s', '%s' ),
            array( '%s', '%s' )
        );

        if ( false === $updated || 0 === (int) $updated ) {
            return false;
        }

        wp_cache_delete( $option_key, 'options' );

        return true;
    }

    protected function acquire_randomizer_job_lock( $token ) {
        $token      = sanitize_key( (string) $token );
        $option_key = $this->get_job_lock_option_key( $token );
        $lock       = $this->get_randomizer_job_lock_payload( $token );

        if ( '' === $token ) {
            return false;
        }

        if ( add_option( $option_key, $lock, '', 'no' ) ) {
            delete_transient( $this->get_job_lock_transient_key( $token ) );
            return true;
        }

        $existing_lock = get_option( $option_key, '__pdr_missing_lock__' );

        if ( '__pdr_missing_lock__' === $existing_lock ) {
            return add_option( $option_key, $lock, '', 'no' );
        }

        if ( ! $this->is_randomizer_job_lock_expired( $existing_lock ) ) {
            return false;
        }

        if ( get_transient( $this->get_job_lock_transient_key( $token ) ) ) {
            return false;
        }

        if ( $this->update_randomizer_job_lock_option( $option_key, $existing_lock, $lock ) ) {
            delete_transient( $this->get_job_lock_transient_key( $token ) );
            return true;
        }

        return false;
    }

    protected function release_randomizer_job_lock( $token ) {
        delete_option( $this->get_job_lock_option_key( $token ) );
        delete_transient( $this->get_job_lock_transient_key( $token ) );
    }

    protected function schedule_randomizer_job_cron( $token ) {
        $token = sanitize_key( (string) $token );

        if ( '' === $token ) {
            return;
        }

        if ( false !== wp_next_scheduled( self::JOB_CRON_HOOK, array( $token ) ) ) {
            return;
        }

        wp_schedule_single_event( time() + 15, self::JOB_CRON_HOOK, array( $token ) );
    }

    protected function get_randomizer_job_loopback_action() {
        return 'pdr_continue_job';
    }

    /**
     * Build the signed job token used by the unauthenticated loopback corridor.
     * This must remain limited to local/background continuation and must not be
     * expanded to authorize unrelated actions without a security review.
     */
    protected function get_randomizer_job_loopback_signature( $token ) {
        $token = sanitize_key( (string) $token );

        if ( '' === $token ) {
            return '';
        }

        return hash_hmac( 'sha256', 'pdr_loopback_job|' . $token, wp_salt( 'nonce' ) );
    }

    /**
     * Validate that the loopback request carries a valid signed job token.
     * The nopriv endpoint must reject unsigned or mismatched tokens and must stay
     * scoped to non-blocking job continuation only.
     */
    protected function is_valid_randomizer_job_loopback_signature( $token, $signature ) {
        $expected = $this->get_randomizer_job_loopback_signature( $token );
        $provided = (string) $signature;

        if ( '' === $expected || '' === $provided ) {
            return false;
        }

        return hash_equals( $expected, $provided );
    }

    /**
     * Dispatch a non-blocking local loopback for background continuation.
     * The request targets the signed continuation endpoint only; do not add
     * unrelated behavior to this corridor without a security review.
     */
    protected function dispatch_randomizer_job_loopback( $token ) {
        $token = sanitize_key( (string) $token );

        if ( '' === $token ) {
            return;
        }

        wp_remote_post(
            admin_url( 'admin-post.php' ),
            array(
                'timeout'   => 0.01,
                'blocking'  => false,
                'sslverify' => apply_filters( 'https_local_ssl_verify', false ),
                'body'      => array(
                    'action'        => $this->get_randomizer_job_loopback_action(),
                    'pdr_job_token' => $token,
                    'pdr_job_sig'   => $this->get_randomizer_job_loopback_signature( $token ),
                ),
            )
        );
    }

    protected function clear_randomizer_job_cron( $token ) {
        $token = sanitize_key( (string) $token );

        if ( '' === $token ) {
            return;
        }

        wp_clear_scheduled_hook( self::JOB_CRON_HOOK, array( $token ) );
    }

}
