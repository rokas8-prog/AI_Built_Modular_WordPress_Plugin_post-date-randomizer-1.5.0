<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait PDR_Job_Notices_Trait {

    protected function get_notice_transient_key( $token ) {
        return PDR_Key_Utils::notice_key( $token );
    }

    protected function get_completed_job_notice_transient_key( $token ) {
        return PDR_Key_Utils::completed_job_notice_key( $token );
    }

    protected function store_completed_randomizer_job_notice_token( $token, $notice_token ) {
        set_transient( $this->get_completed_job_notice_transient_key( $token ), sanitize_key( (string) $notice_token ), HOUR_IN_SECONDS );
    }

    protected function consume_completed_randomizer_job_notice_token( $token ) {
        $notice_token = get_transient( $this->get_completed_job_notice_transient_key( $token ) );
        delete_transient( $this->get_completed_job_notice_transient_key( $token ) );

        if ( ! is_string( $notice_token ) || '' === $notice_token ) {
            return '';
        }

        return sanitize_key( $notice_token );
    }

    protected function build_run_notice_payload( $type, $message ) {
        $allowed_types = array( 'success', 'warning', 'error' );
        $type          = sanitize_key( (string) $type );

        if ( ! in_array( $type, $allowed_types, true ) ) {
            $type = 'warning';
        }

        return array(
            'type'    => $type,
            'message' => (string) $message,
        );
    }

    protected function store_run_notice_payloads( $payloads ) {
        $token    = $this->create_job_token();
        $payloads = $this->normalize_run_notice_payloads( $payloads );
        set_transient( $this->get_notice_transient_key( $token ), $payloads, MINUTE_IN_SECONDS * 10 );
        return $token;
    }

    protected function consume_run_notice_payloads( $token ) {
        $payloads = get_transient( $this->get_notice_transient_key( $token ) );
        delete_transient( $this->get_notice_transient_key( $token ) );
        return $this->normalize_run_notice_payloads( $payloads );
    }

    protected function normalize_run_notice_payloads( $payloads ) {
        if ( is_string( $payloads ) ) {
            $payloads = $this->convert_legacy_run_notice_html_to_payloads( $payloads );
        }

        if ( empty( $payloads ) || ! is_array( $payloads ) ) {
            return array();
        }

        if ( isset( $payloads['type'] ) || isset( $payloads['message'] ) ) {
            $payloads = array( $payloads );
        }

        $normalized = array();

        foreach ( $payloads as $payload ) {
            if ( ! is_array( $payload ) ) {
                continue;
            }

            $normalized[] = $this->build_run_notice_payload(
                isset( $payload['type'] ) ? $payload['type'] : 'warning',
                isset( $payload['message'] ) ? $payload['message'] : ''
            );
        }

        return $normalized;
    }

    /**
     * Normalize legacy HTML notice payloads into the current structured array format.
     *
     * Current notices use structured payload arrays. This bridge exists only for
     * old HTML notice payloads and must not be used for new notice formats.
     *
     * @param string $html Legacy notice HTML.
     * @return array<int, array<string, string>>
     */
    protected function convert_legacy_run_notice_html_to_payloads( $html ) {
        $html = (string) $html;

        if ( '' === $html ) {
            return array();
        }

        $type = 'warning';

        if ( false !== strpos( $html, 'notice-success' ) ) {
            $type = 'success';
        } elseif ( false !== strpos( $html, 'notice-error' ) ) {
            $type = 'error';
        }

        $message = wp_strip_all_tags( $html );

        if ( '' === $message ) {
            return array();
        }

        return array(
            $this->build_run_notice_payload( $type, $message ),
        );
    }

    protected function render_run_notice_payloads( $payloads ) {
        $payloads = $this->normalize_run_notice_payloads( $payloads );

        if ( empty( $payloads ) ) {
            return '';
        }

        $html = '';

        foreach ( $payloads as $payload ) {
            $html .= sprintf(
                '<div class="notice notice-%1$s"><p>%2$s</p></div>',
                esc_attr( $payload['type'] ),
                esc_html( $payload['message'] )
            );
        }

        return $html;
    }
}
