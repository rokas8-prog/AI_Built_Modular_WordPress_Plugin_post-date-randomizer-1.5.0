<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait PDR_Settings_Trait {

    protected function get_default_datetime_from() {
        return PDR_Date_Utils::get_default_randomization_start_datetime();
    }

    protected function get_default_datetime_to() {
        return PDR_Date_Utils::get_default_randomization_end_datetime();
    }

    protected function get_settings_schema() {
        return array(
            'pdr_randomize_posts' => array(
                'type'              => 'checkbox',
                'sanitize_callback' => 'sanitize_checkbox',
                'default'           => 1,
                'label'             => __( 'Randomize posts', 'post-date-randomizer' ),
                'field_renderer'    => 'checkbox',
                'checkbox_label'    => __( 'Randomize entries of the selected post type', 'post-date-randomizer' ),
            ),
            'pdr_randomize_comments' => array(
                'type'              => 'checkbox',
                'sanitize_callback' => 'sanitize_checkbox',
                'default'           => 0,
                'label'             => __( 'Randomize comments', 'post-date-randomizer' ),
                'field_renderer'    => 'checkbox',
                'checkbox_label'    => __( 'Randomize comment dates', 'post-date-randomizer' ),
            ),
            'pdr_post_type' => array(
                'type'              => 'post_type',
                'sanitize_callback' => 'sanitize_post_type_option',
                'default'           => 'post',
                'label'             => __( 'Post type to randomize', 'post-date-randomizer' ),
                'field_renderer'    => 'post_type',
                'description'       => __( 'For example: post, page, product, etc.', 'post-date-randomizer' ),
            ),
            'pdr_set_modified_date' => array(
                'type'              => 'checkbox',
                'sanitize_callback' => 'sanitize_checkbox',
                'default'           => 1,
                'label'             => __( 'Set post_modified = post_date', 'post-date-randomizer' ),
                'field_renderer'    => 'checkbox',
                'checkbox_label'    => __( 'After randomization, post_modified will be matched to the new post_date.', 'post-date-randomizer' ),
            ),
            'pdr_date_from' => array(
                'type'              => 'datetime',
                'sanitize_callback' => 'sanitize_date_from_option',
                'default'           => $this->get_default_datetime_from(),
                'label'             => __( 'Random date range – from', 'post-date-randomizer' ),
                'field_renderer'    => 'datetime',
                'placeholder'       => '2024-01-01 00:00:00',
                'description'       => __( 'New random dates will be generated starting from this date.', 'post-date-randomizer' ),
            ),
            'pdr_date_to' => array(
                'type'              => 'datetime',
                'sanitize_callback' => 'sanitize_date_to_option',
                'default'           => $this->get_default_datetime_to(),
                'label'             => __( 'Random date range – to', 'post-date-randomizer' ),
                'field_renderer'    => 'datetime',
                'placeholder'       => '2025-01-01 23:59:59',
                'description'       => __( 'New random dates will be generated up to and including this date.', 'post-date-randomizer' ),
            ),
            'pdr_filter_date_from' => array(
                'type'              => 'datetime_optional',
                'sanitize_callback' => 'sanitize_filter_date_from_option',
                'default'           => '',
                'label'             => __( 'Filter posts (current date) – from', 'post-date-randomizer' ),
                'field_renderer'    => 'datetime_optional',
                'placeholder'       => 'e.g.: 2020-01-01 00:00:00',
                'description'       => __( 'Filter posts whose CURRENT post_date is on or after this date. Leave empty if no filter is needed.', 'post-date-randomizer' ),
            ),
            'pdr_filter_date_to' => array(
                'type'              => 'datetime_optional',
                'sanitize_callback' => 'sanitize_filter_date_to_option',
                'default'           => '',
                'label'             => __( 'Filter posts (current date) – to', 'post-date-randomizer' ),
                'field_renderer'    => 'datetime_optional',
                'placeholder'       => 'e.g.: 2020-12-31 23:59:59',
                'description'       => __( 'Filter posts whose CURRENT post_date is on or before this date. Leave empty if no filter is needed.', 'post-date-randomizer' ),
            ),
        );
    }

    protected function get_setting_definition( $option_name ) {
        $schema = $this->get_settings_schema();
        return isset( $schema[ $option_name ] ) ? $schema[ $option_name ] : null;
    }

    protected function get_setting_default( $option_name ) {
        $definition = $this->get_setting_definition( $option_name );
        return $definition && array_key_exists( 'default', $definition ) ? $definition['default'] : '';
    }

    protected function get_registered_public_post_types() {
        return get_post_types(
            array(
                'public' => true,
            ),
            'objects'
        );
    }

    protected function is_valid_mysql_datetime( $value ) {
        return PDR_Date_Utils::is_valid_mysql_datetime( $value );
    }

    protected function get_previous_or_default_value( $option_name ) {
        $previous = get_option( $option_name, null );
        if ( null !== $previous ) {
            return $previous;
        }
        return $this->get_setting_default( $option_name );
    }

    protected function get_raw_submitted_option_value( $option_name ) {
        if ( isset( $_POST[ $option_name ] ) ) {
            return wp_unslash( $_POST[ $option_name ] );
        }
        return null;
    }

    protected function sanitize_datetime_for_save( $option_name, $value, $allow_empty = false ) {
        $value = trim( sanitize_text_field( wp_unslash( $value ) ) );

        if ( '' === $value ) {
            if ( $allow_empty ) {
                return '';
            }

            add_settings_error(
                self::OPTION_GROUP,
                $option_name . '_invalid_datetime',
                __( 'Invalid date format. Use the format YYYY-MM-DD HH:MM:SS.', 'post-date-randomizer' ),
                'error'
            );
            return $this->get_previous_or_default_value( $option_name );
        }

        if ( ! $this->is_valid_mysql_datetime( $value ) ) {
            add_settings_error(
                self::OPTION_GROUP,
                $option_name . '_invalid_datetime',
                __( 'Invalid date format. Use the format YYYY-MM-DD HH:MM:SS.', 'post-date-randomizer' ),
                'error'
            );
            return $this->get_previous_or_default_value( $option_name );
        }

        return $value;
    }

    protected function get_sanitized_peer_datetime_value( $option_name, $allow_empty = false ) {
        $raw_value = $this->get_raw_submitted_option_value( $option_name );

        if ( null === $raw_value ) {
            $saved_value = get_option( $option_name, $this->get_setting_default( $option_name ) );
            $saved_value = is_string( $saved_value ) ? trim( $saved_value ) : '';
            if ( '' === $saved_value && $allow_empty ) {
                return '';
            }
            return $this->is_valid_mysql_datetime( $saved_value ) ? $saved_value : $this->get_setting_default( $option_name );
        }

        $submitted_value = trim( sanitize_text_field( $raw_value ) );
        if ( '' === $submitted_value && $allow_empty ) {
            return '';
        }

        return $this->is_valid_mysql_datetime( $submitted_value ) ? $submitted_value : null;
    }

    protected function validate_randomization_interval_on_save( $option_name, $value ) {
        $from = 'pdr_date_from' === $option_name ? $value : $this->get_sanitized_peer_datetime_value( 'pdr_date_from', false );
        $to   = 'pdr_date_to' === $option_name ? $value : $this->get_sanitized_peer_datetime_value( 'pdr_date_to', false );

        if ( ! is_string( $from ) || ! is_string( $to ) || ! $this->is_valid_mysql_datetime( $from ) || ! $this->is_valid_mysql_datetime( $to ) ) {
            return $value;
        }

        $comparison = PDR_Date_Utils::compare_mysql_datetimes( $from, $to );

        if ( null !== $comparison && 0 <= $comparison ) {
            add_settings_error(
                self::OPTION_GROUP,
                'pdr_date_interval_invalid',
                __( 'The randomization date range start must be earlier than the end.', 'post-date-randomizer' ),
                'error'
            );
            return $this->get_previous_or_default_value( $option_name );
        }

        return $value;
    }

    protected function validate_filter_interval_on_save( $option_name, $value ) {
        $from = 'pdr_filter_date_from' === $option_name ? $value : $this->get_sanitized_peer_datetime_value( 'pdr_filter_date_from', true );
        $to   = 'pdr_filter_date_to' === $option_name ? $value : $this->get_sanitized_peer_datetime_value( 'pdr_filter_date_to', true );

        if ( '' === $from || '' === $to ) {
            return $value;
        }

        if ( ! is_string( $from ) || ! is_string( $to ) || ! $this->is_valid_mysql_datetime( $from ) || ! $this->is_valid_mysql_datetime( $to ) ) {
            return $value;
        }

        $comparison = PDR_Date_Utils::compare_mysql_datetimes( $from, $to );

        if ( null !== $comparison && 0 <= $comparison ) {
            add_settings_error(
                self::OPTION_GROUP,
                'pdr_filter_date_interval_invalid',
                __( 'The filter date range start must be earlier than the end.', 'post-date-randomizer' ),
                'error'
            );
            return $this->get_previous_or_default_value( $option_name );
        }

        return $value;
    }

    protected function get_field_definition( $option_name ) {
        $definition = $this->get_setting_definition( $option_name );
        return is_array( $definition ) ? $definition : array();
    }

    protected function render_checkbox_field_from_schema( $option_name ) {
        $definition = $this->get_field_definition( $option_name );
        $value      = get_option( $option_name, $this->get_setting_default( $option_name ) );
        ?>
        <label>
            <input type="checkbox" name="<?php echo esc_attr( $option_name ); ?>" value="1" <?php checked( $value, 1 ); ?> />
            <?php echo esc_html( isset( $definition['checkbox_label'] ) ? $definition['checkbox_label'] : '' ); ?>
        </label>
        <?php
    }

    protected function render_datetime_field_from_schema( $option_name ) {
        $definition  = $this->get_field_definition( $option_name );
        $value       = get_option( $option_name, $this->get_setting_default( $option_name ) );
        $placeholder = isset( $definition['placeholder'] ) ? $definition['placeholder'] : '';
        $description = isset( $definition['description'] ) ? $definition['description'] : '';
        ?>
        <input type="text"
               name="<?php echo esc_attr( $option_name ); ?>"
               value="<?php echo esc_attr( $value ); ?>"
               class="regular-text"
               placeholder="<?php echo esc_attr( $placeholder ); ?>" />
        <p class="description">
            <?php echo esc_html( $description ); ?>
        </p>
        <?php
    }

    public function sanitize_checkbox( $value ) {
        return ! empty( $value ) ? 1 : 0;
    }


    public function sanitize_post_type_option( $value ) {
        $value      = sanitize_text_field( wp_unslash( $value ) );
        $post_types = $this->get_registered_public_post_types();

        if ( isset( $post_types[ $value ] ) ) {
            return $value;
        }

        add_settings_error(
            self::OPTION_GROUP,
            'pdr_post_type_invalid',
            __( 'The selected post type is invalid.', 'post-date-randomizer' ),
            'error'
        );

        return $this->get_previous_or_default_value( 'pdr_post_type' );
    }

    public function sanitize_date_from_option( $value ) {
        $value = $this->sanitize_datetime_for_save( 'pdr_date_from', $value, false );
        return $this->validate_randomization_interval_on_save( 'pdr_date_from', $value );
    }

    public function sanitize_date_to_option( $value ) {
        $value = $this->sanitize_datetime_for_save( 'pdr_date_to', $value, false );
        return $this->validate_randomization_interval_on_save( 'pdr_date_to', $value );
    }

    public function sanitize_filter_date_from_option( $value ) {
        $value = $this->sanitize_datetime_for_save( 'pdr_filter_date_from', $value, true );
        return $this->validate_filter_interval_on_save( 'pdr_filter_date_from', $value );
    }

    public function sanitize_filter_date_to_option( $value ) {
        $value = $this->sanitize_datetime_for_save( 'pdr_filter_date_to', $value, true );
        return $this->validate_filter_interval_on_save( 'pdr_filter_date_to', $value );
    }
}
