<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait PDR_Admin_Trait {

    public function add_menu_page() {
        add_menu_page(
            __( 'Date Randomizer', 'post-date-randomizer' ),
            __( 'Date Randomizer', 'post-date-randomizer' ),
            'manage_options',
            self::SETTINGS_PAGE,
            array( $this, 'render_settings_page' ),
            'dashicons-randomize',
            81
        );
    }

    public function register_settings() {
        foreach ( $this->get_settings_schema() as $option_name => $definition ) {
            register_setting(
                self::OPTION_GROUP,
                $option_name,
                array(
                    'type'              => $definition['type'],
                    'sanitize_callback' => array( $this, $definition['sanitize_callback'] ),
                    'default'           => $definition['default'],
                )
            );
        }

        add_settings_section(
            'pdr_main_section',
            __( 'Post Date Randomizer Settings', 'post-date-randomizer' ),
            array( $this, 'render_section_description' ),
            self::SETTINGS_PAGE
        );

        foreach ( $this->get_settings_schema() as $option_name => $definition ) {
            $callback = 'post_type' === $definition['field_renderer']
                ? array( $this, 'field_post_type' )
                : array( $this, 'render_schema_field' );

            add_settings_field(
                $option_name,
                $definition['label'],
                $callback,
                self::SETTINGS_PAGE,
                'pdr_main_section',
                array(
                    'option_name' => $option_name,
                    'field_type'  => $definition['field_renderer'],
                )
            );
        }
    }

    public function render_section_description() {
        echo '<p>';
        echo esc_html__(
            'Choose what to randomize: posts, comments, the post type to use, and the date range for generating new dates.',
            'post-date-randomizer'
        );
        echo '</p>';

        echo '<p>';
        echo esc_html__(
            'You can also limit which posts are changed based on their current post_date value using the filter date range.',
            'post-date-randomizer'
        );
        echo '</p>';

        echo '<p><strong>';
        echo esc_html__( 'Date format:', 'post-date-randomizer' );
        echo ' </strong> ';
        echo esc_html__( 'YYYY-MM-DD HH:MM:SS (for example: 2024-01-15 10:30:00)', 'post-date-randomizer' );
        echo '</p>';
    }

    protected function get_run_request_page() {
        return PDR_Request_Utils::get_key( $_GET, 'page' );
    }

    protected function get_run_request_trigger() {
        return PDR_Request_Utils::get_text( $_POST, 'pdr_run_randomize', null );
    }

    protected function get_run_request_job_token() {
        return PDR_Request_Utils::get_key( $_GET, 'pdr_run_job' );
    }

    protected function get_run_notice_token() {
        return PDR_Request_Utils::get_key( $_GET, 'pdr_notice' );
    }

    public function maybe_handle_run_action() {
        if ( ! is_admin() ) {
            return;
        }

        if ( self::SETTINGS_PAGE !== $this->get_run_request_page() ) {
            return;
        }

        $notice_token = $this->get_run_notice_token();
        if ( '' !== $notice_token ) {
            $this->run_action_notices = $this->consume_run_notice_payloads( $notice_token );
            return;
        }

        if ( null !== $this->get_run_request_trigger() ) {
            $this->handle_randomize_request();
            return;
        }

        $job_token = $this->get_run_request_job_token();
        if ( '' === $job_token ) {
            return;
        }

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( __( 'You do not have permission to perform this action.', 'post-date-randomizer' ) );
        }

        $completed_notice_token = $this->consume_completed_randomizer_job_notice_token( $job_token );
        if ( '' !== $completed_notice_token ) {
            wp_safe_redirect( $this->get_randomizer_page_url( array( 'pdr_notice' => $completed_notice_token ) ) );
            exit;
        }

        $result = $this->process_randomizer_job_token_chunk( $job_token );

        if ( 'missing' === $result['status'] ) {
            $notice_token = $this->store_run_notice_payloads(
                array(
                    $this->build_run_notice_payload(
                        'warning',
                        __( 'No posts or comments were found for randomization with the selected settings.', 'post-date-randomizer' )
                    ),
                )
            );
            wp_safe_redirect( $this->get_randomizer_page_url( array( 'pdr_notice' => $notice_token ) ) );
            exit;
        }

        if ( 'done' === $result['status'] ) {
            wp_safe_redirect( $this->get_randomizer_page_url( array( 'pdr_notice' => $result['notice_token'] ) ) );
            exit;
        }

        wp_safe_redirect( $this->get_randomizer_page_url( array( 'pdr_run_job' => $job_token ) ) );
        exit;
    }

    public function render_schema_field( $args ) {
        $option_name = isset( $args['option_name'] ) ? $args['option_name'] : '';
        $field_type  = isset( $args['field_type'] ) ? $args['field_type'] : '';

        if ( 'checkbox' === $field_type ) {
            $this->render_checkbox_field_from_schema( $option_name );
            return;
        }

        if ( 'datetime' === $field_type || 'datetime_optional' === $field_type ) {
            $this->render_datetime_field_from_schema( $option_name );
        }
    }

    public function field_post_type() {
        $current    = get_option( 'pdr_post_type', $this->get_setting_default( 'pdr_post_type' ) );
        $post_types = $this->get_registered_public_post_types();

        echo '<select name="pdr_post_type">';
        foreach ( $post_types as $slug => $pt ) {
            printf(
                '<option value="%s"%s>%s (%s)</option>',
                esc_attr( $slug ),
                selected( $slug, $current, false ),
                esc_html( $pt->labels->singular_name ),
                esc_html( $slug )
            );
        }
        echo '</select>';
        echo '<p class="description">';
        esc_html_e( 'For example: post, page, product, etc.', 'post-date-randomizer' );
        echo '</p>';
    }

    public function render_settings_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        echo $this->render_run_notice_payloads( $this->run_action_notices );

        require trailingslashit( dirname( __DIR__ ) ) . 'admin/views/settings-page.php';
    }
}
