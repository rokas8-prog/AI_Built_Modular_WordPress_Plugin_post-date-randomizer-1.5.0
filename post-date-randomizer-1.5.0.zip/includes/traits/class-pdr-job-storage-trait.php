<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait PDR_Job_Storage_Trait {

    protected function get_job_transient_key( $token ) {
        return PDR_Key_Utils::job_key( $token );
    }

    protected function get_job_option_key( $token ) {
        return $this->get_job_transient_key( $token );
    }

    protected function create_job_token() {
        return wp_generate_password( 20, false, false );
    }

    protected function get_randomizer_job_storage_timestamp() {
        return current_time( 'mysql' );
    }

    protected function prepare_randomizer_job_for_storage( $job ) {
        $job       = $this->normalize_randomizer_job_state( $job );
        $timestamp = $this->get_randomizer_job_storage_timestamp();

        if ( empty( $job['created_at'] ) ) {
            $job['created_at'] = $timestamp;
        }

        $job['updated_at'] = $timestamp;

        return $job;
    }

    protected function persist_randomizer_job_option( $token, $job ) {
        $option_key = $this->get_job_option_key( $token );
        $existing   = get_option( $option_key, '__pdr_missing_job__' );

        if ( '__pdr_missing_job__' === $existing ) {
            add_option( $option_key, $job, '', 'no' );
            return;
        }

        update_option( $option_key, $job );
    }

    protected function start_randomizer_job( $job ) {
        $token = $this->create_job_token();
        $this->save_randomizer_job( $token, $job );
        return $token;
    }

    protected function load_randomizer_job( $token ) {
        $option_key = $this->get_job_option_key( $token );
        $job        = get_option( $option_key, '__pdr_missing_job__' );

        if ( is_array( $job ) ) {
            return $this->normalize_randomizer_job_state( $job );
        }

        /*
         * Legacy compatibility bridge: current jobs are stored in non-autoloaded
         * options. This transient fallback exists only to migrate/finish older
         * jobs that were created before option-backed storage. Do not expand
         * this fallback; future removal requires a separate compatibility decision.
         */
        $legacy_job = get_transient( $this->get_job_transient_key( $token ) );

        if ( ! is_array( $legacy_job ) ) {
            return null;
        }

        $legacy_job = $this->prepare_randomizer_job_for_storage( $legacy_job );
        $this->persist_randomizer_job_option( $token, $legacy_job );
        delete_transient( $this->get_job_transient_key( $token ) );

        return $this->normalize_randomizer_job_state( $legacy_job );
    }

    protected function save_randomizer_job( $token, $job ) {
        $job = $this->prepare_randomizer_job_for_storage( $job );
        $this->persist_randomizer_job_option( $token, $job );
    }

    protected function delete_randomizer_job( $token ) {
        delete_option( $this->get_job_option_key( $token ) );
        delete_transient( $this->get_job_transient_key( $token ) );
    }

    protected function build_job_snapshot() {
        $randomize_posts    = (bool) get_option( 'pdr_randomize_posts', 1 );
        $randomize_comments = (bool) get_option( 'pdr_randomize_comments', 0 );
        $post_type          = get_option( 'pdr_post_type', 'post' );
        $set_modified       = (bool) get_option( 'pdr_set_modified_date', 1 );

        $date_from_str = get_option( 'pdr_date_from', $this->get_default_datetime_from() );
        $date_to_str   = get_option( 'pdr_date_to', $this->get_default_datetime_to() );

        $filter_from_str = get_option( 'pdr_filter_date_from', '' );
        $filter_to_str   = get_option( 'pdr_filter_date_to', '' );

        $phase = 'done';
        if ( $randomize_posts ) {
            $phase = 'posts';
        } elseif ( $randomize_comments ) {
            $phase = 'comments';
        }

        return array(
            'randomize_posts'    => $randomize_posts,
            'randomize_comments' => $randomize_comments,
            'post_type'          => $post_type,
            'set_modified_date'  => $set_modified,
            'date_from'          => $date_from_str,
            'date_to'            => $date_to_str,
            'filter_date_from'   => $filter_from_str,
            'filter_date_to'     => $filter_to_str,
            'phase'              => $phase,
            'last_post_id'       => 0,
            'last_comment_id'    => 0,
            'posts_processed'    => 0,
            'comments_processed' => 0,
            'created_at'         => current_time( 'mysql' ),
            'updated_at'         => current_time( 'mysql' ),
            'started_by_user'    => get_current_user_id(),
            'done'               => ( 'done' === $phase ),
        );
    }

    protected function normalize_randomizer_job_state( $job ) {
        if ( ! isset( $job['posts_processed'] ) ) {
            $job['posts_processed'] = 0;
        }

        if ( ! isset( $job['comments_processed'] ) ) {
            $job['comments_processed'] = 0;
        }

        if ( ! isset( $job['last_post_id'] ) ) {
            $job['last_post_id'] = 0;
            if ( ! empty( $job['post_queue'] ) && ! empty( $job['post_cursor'] ) ) {
                $index = (int) $job['post_cursor'] - 1;
                if ( isset( $job['post_queue'][ $index ] ) ) {
                    $job['last_post_id'] = (int) $job['post_queue'][ $index ];
                }
            }
        }

        if ( ! isset( $job['last_comment_id'] ) ) {
            $job['last_comment_id'] = 0;
            if ( ! empty( $job['comment_queue'] ) && ! empty( $job['comment_cursor'] ) ) {
                $index = (int) $job['comment_cursor'] - 1;
                if ( isset( $job['comment_queue'][ $index ] ) ) {
                    $job['last_comment_id'] = (int) $job['comment_queue'][ $index ];
                }
            }
        }

        if ( ! isset( $job['phase'] ) ) {
            $job['phase'] = 'done';

            if ( ! empty( $job['randomize_posts'] ) ) {
                $has_posts_remaining = false;

                if ( isset( $job['post_cursor'], $job['post_total'] ) ) {
                    $has_posts_remaining = ( (int) $job['post_cursor'] < (int) $job['post_total'] );
                } elseif ( ! empty( $job['post_queue'] ) ) {
                    $has_posts_remaining = true;
                }

                if ( $has_posts_remaining ) {
                    $job['phase'] = 'posts';
                }
            }

            if ( 'done' === $job['phase'] && ! empty( $job['randomize_comments'] ) ) {
                $has_comments_remaining = false;

                if ( isset( $job['comment_cursor'], $job['comment_total'] ) ) {
                    $has_comments_remaining = ( (int) $job['comment_cursor'] < (int) $job['comment_total'] );
                } elseif ( ! empty( $job['comment_queue'] ) ) {
                    $has_comments_remaining = true;
                }

                if ( $has_comments_remaining ) {
                    $job['phase'] = 'comments';
                }
            }
        }

        if ( empty( $job['created_at'] ) ) {
            $job['created_at'] = $this->get_randomizer_job_storage_timestamp();
        }

        if ( empty( $job['updated_at'] ) ) {
            $job['updated_at'] = $job['created_at'];
        }

        if ( ! isset( $job['started_by_user'] ) ) {
            $job['started_by_user'] = 0;
        }

        $job['last_post_id']    = (int) $job['last_post_id'];
        $job['last_comment_id'] = (int) $job['last_comment_id'];
        $job['done']            = ! empty( $job['done'] ) || ( 'done' === $job['phase'] );

        unset( $job['post_queue'], $job['comment_queue'], $job['post_total'], $job['comment_total'], $job['post_cursor'], $job['comment_cursor'] );

        return $job;
    }
    protected function get_randomizer_job_stale_age() {
        return DAY_IN_SECONDS;
    }

    protected function get_randomizer_job_updated_timestamp( $job ) {
        if ( ! is_array( $job ) || empty( $job['updated_at'] ) ) {
            return 0;
        }

        $timestamp = PDR_Date_Utils::parse_mysql_datetime_to_timestamp( (string) $job['updated_at'] );

        if ( false === $timestamp ) {
            return 0;
        }

        return (int) $timestamp;
    }

    protected function get_stale_randomizer_job_tokens() {
        global $wpdb;

        $prefix     = $wpdb->esc_like( 'pdr_job_' );
        $lock_prefix = $wpdb->esc_like( 'pdr_job_lock_' );
        $cutoff_ts  = current_time( 'timestamp' ) - (int) $this->get_randomizer_job_stale_age();
        $rows       = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT option_name, option_value FROM {$wpdb->options} WHERE option_name LIKE %s AND option_name NOT LIKE %s",
                $prefix . '%',
                $lock_prefix . '%'
            ),
            ARRAY_A
        );
        $tokens     = array();

        if ( empty( $rows ) ) {
            return $tokens;
        }

        foreach ( $rows as $row ) {
            if ( empty( $row['option_name'] ) ) {
                continue;
            }

            $token = sanitize_key( substr( $row['option_name'], strlen( 'pdr_job_' ) ) );

            if ( '' === $token ) {
                continue;
            }

            $job = maybe_unserialize( $row['option_value'] );

            if ( ! is_array( $job ) ) {
                continue;
            }

            $job        = $this->normalize_randomizer_job_state( $job );
            $updated_ts = $this->get_randomizer_job_updated_timestamp( $job );

            if ( $updated_ts && $updated_ts < $cutoff_ts ) {
                $tokens[] = $token;
            }
        }

        return array_values( array_unique( $tokens ) );
    }

}
