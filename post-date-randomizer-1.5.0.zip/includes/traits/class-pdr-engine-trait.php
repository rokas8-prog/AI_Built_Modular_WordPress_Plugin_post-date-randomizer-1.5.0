<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait PDR_Engine_Trait {

    protected function get_run_nonce_value() {
        return PDR_Request_Utils::get_text( $_POST, 'pdr_run_nonce' );
    }

    /**
     * Handle randomization trigger.
     */
    protected function handle_randomize_request() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( __( 'You do not have permission to perform this action.', 'post-date-randomizer' ) );
        }

        $nonce = $this->get_run_nonce_value();
        if ( '' === $nonce || ! wp_verify_nonce( $nonce, 'pdr_run_randomize_action' ) ) {
            wp_die( __( 'Security check failed (Nonce mismatch).', 'post-date-randomizer' ) );
        }

        $randomize_posts    = (bool) get_option( 'pdr_randomize_posts', 1 );
        $randomize_comments = (bool) get_option( 'pdr_randomize_comments', 0 );

        $date_from_str = get_option( 'pdr_date_from', $this->get_default_datetime_from() );
        $date_to_str   = get_option( 'pdr_date_to', $this->get_default_datetime_to() );

        $date_from_ts = PDR_Date_Utils::parse_mysql_datetime_to_timestamp( $date_from_str );
        $date_to_ts   = PDR_Date_Utils::parse_mysql_datetime_to_timestamp( $date_to_str );

        $filter_from_str = get_option( 'pdr_filter_date_from', '' );
        $filter_to_str   = get_option( 'pdr_filter_date_to', '' );

        $errors = array();

        if ( false === $date_from_ts || false === $date_to_ts ) {
            $errors[] = __( 'Invalid date format. Check “Random date range – from” and “to”.', 'post-date-randomizer' );
        } elseif ( $date_from_ts >= $date_to_ts ) {
            $errors[] = __( 'The randomization date range start must be earlier than the end.', 'post-date-randomizer' );
        }

        $filter_from_ts = null;
        $filter_to_ts   = null;

        if ( '' !== $filter_from_str ) {
            $filter_from_ts = PDR_Date_Utils::parse_mysql_datetime_to_timestamp( $filter_from_str );
            if ( false === $filter_from_ts ) {
                $errors[] = __( 'Invalid filter date format in the “Filter posts (current date) – from” field.', 'post-date-randomizer' );
            }
        }

        if ( '' !== $filter_to_str ) {
            $filter_to_ts = PDR_Date_Utils::parse_mysql_datetime_to_timestamp( $filter_to_str );
            if ( false === $filter_to_ts ) {
                $errors[] = __( 'Invalid filter date format in the “Filter posts (current date) – to” field.', 'post-date-randomizer' );
            }
        }

        if ( null !== $filter_from_ts && false !== $filter_from_ts && null !== $filter_to_ts && false !== $filter_to_ts && $filter_from_ts >= $filter_to_ts ) {
            $errors[] = __( 'The filter date range start must be earlier than the end.', 'post-date-randomizer' );
        }

        if ( ! $randomize_posts && ! $randomize_comments ) {
            $errors[] = __( 'At least one option must be selected: randomize posts or comments.', 'post-date-randomizer' );
        }

        if ( ! empty( $errors ) ) {
            printf( '<div class="notice notice-error"><p>%s</p></div>', esc_html( implode( ' ', $errors ) ) );
            return;
        }

        $job   = $this->build_job_snapshot();
        $token = $this->start_randomizer_job( $job );

        $this->schedule_randomizer_job_cron( $token );
        $this->dispatch_randomizer_job_loopback( $token );

        wp_safe_redirect( $this->get_randomizer_page_url( array( 'pdr_run_job' => $token ) ) );
        exit;
    }

    protected function get_randomizer_page_url( $args = array() ) {
        $url_args = array_merge(
            array(
                'page' => self::SETTINGS_PAGE,
            ),
            $args
        );

        return add_query_arg( $url_args, admin_url( 'admin.php' ) );
    }

    protected function build_randomizer_result_notice_payload( $posts_updated, $comments_updated ) {
        if ( $posts_updated || $comments_updated ) {
            $message = sprintf(
                /* translators: 1: number of posts, 2: number of comments */
                __( 'Randomization completed. Updated posts: %1$d, comments: %2$d.', 'post-date-randomizer' ),
                intval( $posts_updated ),
                intval( $comments_updated )
            );

            return $this->build_run_notice_payload( 'success', $message );
        }

        return $this->build_run_notice_payload(
            'warning',
            __( 'No posts or comments were found for randomization with the selected settings.', 'post-date-randomizer' )
        );
    }


    protected function finalize_randomizer_job( $job_token, $job ) {
        $this->clear_randomizer_job_cron( $job_token );
        $this->delete_randomizer_job( $job_token );

        $notice_token = $this->store_run_notice_payloads(
            array(
                $this->build_randomizer_result_notice_payload( $job['posts_processed'], $job['comments_processed'] ),
            )
        );

        $this->store_completed_randomizer_job_notice_token( $job_token, $notice_token );

        return $notice_token;
    }

    protected function process_randomizer_job_token_chunk( $job_token ) {
        $job_token = sanitize_key( (string) $job_token );

        if ( '' === $job_token ) {
            return array( 'status' => 'missing' );
        }

        if ( ! $this->acquire_randomizer_job_lock( $job_token ) ) {
            return array( 'status' => 'locked' );
        }

        try {
            $job = $this->load_randomizer_job( $job_token );

            if ( ! is_array( $job ) ) {
                $this->clear_randomizer_job_cron( $job_token );
                return array( 'status' => 'missing' );
            }

            $job = $this->process_randomizer_job_chunk( $job );

            if ( ! empty( $job['done'] ) ) {
                return array(
                    'status'       => 'done',
                    'notice_token' => $this->finalize_randomizer_job( $job_token, $job ),
                    'job'          => $job,
                );
            }

            $this->save_randomizer_job( $job_token, $job );
            $this->schedule_randomizer_job_cron( $job_token );
            $this->dispatch_randomizer_job_loopback( $job_token );

            return array(
                'status' => 'running',
                'job'    => $job,
            );
        } finally {
            $this->release_randomizer_job_lock( $job_token );
        }
    }

    public function handle_randomizer_job_cron( $job_token ) {
        $job_token = sanitize_key( (string) $job_token );

        if ( '' === $job_token ) {
            return;
        }

        $result = $this->process_randomizer_job_token_chunk( $job_token );

        if ( 'locked' === $result['status'] ) {
            $this->schedule_randomizer_job_cron( $job_token );
        }
    }

    /**
     * Handle the signed loopback continuation endpoint.
     * This unauthenticated endpoint exists only for non-blocking local/background
     * continuation, must accept only a valid signed job token, and must not perform
     * unrelated actions without a security review.
     */
    public function handle_randomizer_job_loopback() {
        $job_token = PDR_Request_Utils::get_key( $_REQUEST, 'pdr_job_token' );
        $signature = PDR_Request_Utils::get_text( $_REQUEST, 'pdr_job_sig' );

        if ( '' === $job_token || ! $this->is_valid_randomizer_job_loopback_signature( $job_token, $signature ) ) {
            status_header( 403 );
            exit;
        }

        $result = $this->process_randomizer_job_token_chunk( $job_token );

        if ( 'locked' === $result['status'] ) {
            $this->schedule_randomizer_job_cron( $job_token );
        }

        status_header( 200 );
        exit;
    }

    protected function randomize_single_post( $post_id, $from_ts, $to_ts, $set_modified ) {
        $random_ts  = mt_rand( $from_ts, $to_ts );
        $new_date   = PDR_Date_Utils::format_mysql_datetime( $random_ts );
        $new_date_g = get_gmt_from_date( $new_date );

        $postarr = array(
            'ID'            => $post_id,
            'post_date'     => $new_date,
            'post_date_gmt' => $new_date_g,
        );

        if ( $set_modified ) {
            $postarr['post_modified']     = $new_date;
            $postarr['post_modified_gmt'] = $new_date_g;
        }

        $result = wp_update_post( $postarr, true );
        return ! is_wp_error( $result );
    }

    protected function randomize_single_comment( $comment_id, $from_ts, $to_ts ) {
        $random_ts  = mt_rand( $from_ts, $to_ts );
        $new_date   = PDR_Date_Utils::format_mysql_datetime( $random_ts );
        $new_date_g = get_gmt_from_date( $new_date );

        $update = array(
            'comment_ID'       => $comment_id,
            'comment_date'     => $new_date,
            'comment_date_gmt' => $new_date_g,
        );

        return (bool) wp_update_comment( $update );
    }
}
