<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait PDR_Job_Trait {

    protected function get_job_batch_size() {
        return 500;
    }

    protected function process_randomizer_job_chunk( $job ) {
        $batch_size    = $this->get_job_batch_size();
        $from_ts       = PDR_Date_Utils::parse_mysql_datetime_to_timestamp( $job['date_from'] );
        $to_ts         = PDR_Date_Utils::parse_mysql_datetime_to_timestamp( $job['date_to'] );
        $set_modified  = ! empty( $job['set_modified_date'] );
        $processed_any = false;

        $job = $this->normalize_randomizer_job_state( $job );

        if ( 'posts' === $job['phase'] && ! empty( $job['randomize_posts'] ) ) {
            $chunk  = $this->fetch_next_post_job_batch_ids(
                $job['post_type'],
                $job['filter_date_from'],
                $job['filter_date_to'],
                $job['last_post_id'],
                $batch_size
            );
            $result = $this->process_streaming_job_batch( $chunk, 'randomize_single_post', array( $from_ts, $to_ts, $set_modified ) );

            if ( ! empty( $result['has_ids'] ) ) {
                $job           = $this->apply_streaming_job_batch_result( $job, $result, 'last_post_id', 'posts_processed' );
                $processed_any = true;

                if ( empty( $result['has_more'] ) ) {
                    $job['phase'] = ! empty( $job['randomize_comments'] ) ? 'comments' : 'done';
                    $job['done']  = ( 'done' === $job['phase'] );
                }
            } else {
                $job['phase'] = ! empty( $job['randomize_comments'] ) ? 'comments' : 'done';
                $job['done']  = ( 'done' === $job['phase'] );
            }
        }

        if ( ! $processed_any && 'comments' === $job['phase'] && ! empty( $job['randomize_comments'] ) ) {
            $chunk  = $this->fetch_next_comment_job_batch_ids( $job['last_comment_id'], $batch_size );
            $result = $this->process_streaming_job_batch( $chunk, 'randomize_single_comment', array( $from_ts, $to_ts ) );

            if ( ! empty( $result['has_ids'] ) ) {
                $job           = $this->apply_streaming_job_batch_result( $job, $result, 'last_comment_id', 'comments_processed' );
                $processed_any = true;

                if ( empty( $result['has_more'] ) ) {
                    $job['phase'] = 'done';
                    $job['done']  = true;
                }
            } else {
                $job['phase'] = 'done';
                $job['done']  = true;
            }
        }

        if ( ! $processed_any && empty( $job['done'] ) ) {
            $job['phase'] = 'done';
            $job['done']  = true;
        }

        return $this->normalize_randomizer_job_state( $job );
    }

    protected function process_streaming_job_batch( $batch, $callback, $callback_args = array() ) {
        $ids      = $batch;
        $has_more = false;

        if ( is_array( $batch ) && isset( $batch['ids'] ) ) {
            $ids      = $batch['ids'];
            $has_more = ! empty( $batch['has_more'] );
        }

        $result = array(
            'processed_count' => 0,
            'last_id'         => 0,
            'has_ids'         => ! empty( $ids ),
            'has_more'        => $has_more,
        );

        if ( empty( $ids ) ) {
            return $result;
        }

        foreach ( $ids as $id ) {
            $id = (int) $id;

            if ( call_user_func_array( array( $this, $callback ), array_merge( array( $id ), $callback_args ) ) ) {
                $result['processed_count']++;
            }

            $result['last_id'] = $id;
        }

        return $result;
    }

    protected function apply_streaming_job_batch_result( $job, $result, $cursor_key, $processed_key ) {
        if ( empty( $result['has_ids'] ) ) {
            return $job;
        }

        $job[ $cursor_key ]    = (int) $result['last_id'];
        $job[ $processed_key ] += (int) $result['processed_count'];

        return $job;
    }

    /**
     * Internal streaming batch helper. Only supports known posts/comments table and ID column pairs.
     */
    protected function fetch_streaming_job_batch_ids( $table, $id_column, $extra_where_sql = '', $extra_params = array(), $last_id = 0, $limit = null ) {
        global $wpdb;

        $allowed_pairs = array(
            $wpdb->posts    => 'ID',
            $wpdb->comments => 'comment_ID',
        );

        if ( ! is_string( $table ) || ! is_string( $id_column ) || ! isset( $allowed_pairs[ $table ] ) || $allowed_pairs[ $table ] !== $id_column ) {
            return array(
                'ids'      => array(),
                'has_more' => false,
            );
        }

        $limit       = null === $limit ? $this->get_job_batch_size() : (int) $limit;
        $fetch_limit = $limit + 1;
        $sql         = "SELECT {$id_column} FROM {$table} WHERE {$id_column} > %d";
        $params      = array( (int) $last_id );

        if ( '' !== $extra_where_sql ) {
            $sql .= ' ' . $extra_where_sql;
        }

        if ( ! empty( $extra_params ) ) {
            $params = array_merge( $params, $extra_params );
        }

        $sql      .= " ORDER BY {$id_column} ASC LIMIT %d";
        $params[] = $fetch_limit;

        $ids      = array_map( 'intval', $wpdb->get_col( $wpdb->prepare( $sql, $params ) ) );
        $has_more = count( $ids ) > $limit;

        if ( $has_more ) {
            $ids = array_slice( $ids, 0, $limit );
        }

        return array(
            'ids'      => $ids,
            'has_more' => $has_more,
        );
    }

    protected function fetch_next_post_job_batch_ids( $post_type, $filter_from_str = '', $filter_to_str = '', $last_post_id = 0, $limit = null ) {
        global $wpdb;

        $where_sql    = "AND post_type = %s AND post_status = 'publish'";
        $where_params = array( $post_type );

        if ( '' !== $filter_from_str ) {
            $where_sql      .= ' AND post_date >= %s';
            $where_params[] = $filter_from_str;
        }

        if ( '' !== $filter_to_str ) {
            $where_sql      .= ' AND post_date <= %s';
            $where_params[] = $filter_to_str;
        }

        return $this->fetch_streaming_job_batch_ids( $wpdb->posts, 'ID', $where_sql, $where_params, $last_post_id, $limit );
    }

    protected function fetch_next_comment_job_batch_ids( $last_comment_id = 0, $limit = null ) {
        global $wpdb;

        return $this->fetch_streaming_job_batch_ids( $wpdb->comments, 'comment_ID', "AND comment_approved = '1'", array(), $last_comment_id, $limit );
    }
    public function handle_randomizer_job_cleanup_cron() {
        $tokens = $this->get_stale_randomizer_job_tokens();

        if ( empty( $tokens ) ) {
            return;
        }

        foreach ( $tokens as $token ) {
            $this->clear_randomizer_job_cron( $token );
            $this->release_randomizer_job_lock( $token );
            $this->delete_randomizer_job( $token );
        }
    }

}
