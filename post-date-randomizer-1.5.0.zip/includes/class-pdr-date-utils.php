<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PDR_Date_Utils {

    public static function get_timezone() {
        if ( function_exists( 'wp_timezone' ) ) {
            return wp_timezone();
        }

        $timezone_string = function_exists( 'get_option' ) ? get_option( 'timezone_string' ) : '';
        if ( is_string( $timezone_string ) && '' !== $timezone_string ) {
            try {
                return new DateTimeZone( $timezone_string );
            } catch ( Exception $e ) {
                // Fall through to GMT offset handling.
            }
        }

        $offset = function_exists( 'get_option' ) ? (float) get_option( 'gmt_offset', 0 ) : 0;
        $hours  = (int) $offset;
        $mins   = (int) round( abs( $offset - $hours ) * 60 );
        $sign   = ( $offset < 0 ) ? '-' : '+';

        return new DateTimeZone( sprintf( '%s%02d:%02d', $sign, abs( $hours ), $mins ) );
    }

    public static function format_mysql_datetime( $timestamp ) {
        $timestamp = (int) $timestamp;

        if ( function_exists( 'wp_date' ) ) {
            return wp_date( 'Y-m-d H:i:s', $timestamp, self::get_timezone() );
        }

        if ( function_exists( 'date_i18n' ) ) {
            return date_i18n( 'Y-m-d H:i:s', $timestamp );
        }

        $datetime = new DateTime( '@' . $timestamp );
        $datetime->setTimezone( self::get_timezone() );

        return $datetime->format( 'Y-m-d H:i:s' );
    }

    public static function parse_mysql_datetime_to_timestamp( $datetime ) {
        if ( ! self::is_valid_mysql_datetime( $datetime ) ) {
            return false;
        }

        $parsed = DateTime::createFromFormat( '!Y-m-d H:i:s', $datetime, self::get_timezone() );
        if ( ! $parsed ) {
            return false;
        }

        return $parsed->getTimestamp();
    }

    public static function is_valid_mysql_datetime( $value ) {
        if ( ! is_string( $value ) || '' === $value ) {
            return false;
        }

        if ( ! preg_match( '/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $value ) ) {
            return false;
        }

        $datetime = DateTime::createFromFormat( '!Y-m-d H:i:s', $value, self::get_timezone() );
        if ( ! $datetime ) {
            return false;
        }

        $errors = DateTime::getLastErrors();
        if ( ! empty( $errors['warning_count'] ) || ! empty( $errors['error_count'] ) ) {
            return false;
        }

        return $datetime->format( 'Y-m-d H:i:s' ) === $value;
    }

    public static function compare_mysql_datetimes( $first, $second ) {
        $first_timestamp  = self::parse_mysql_datetime_to_timestamp( $first );
        $second_timestamp = self::parse_mysql_datetime_to_timestamp( $second );

        if ( false === $first_timestamp || false === $second_timestamp ) {
            return null;
        }

        if ( $first_timestamp === $second_timestamp ) {
            return 0;
        }

        return ( $first_timestamp < $second_timestamp ) ? -1 : 1;
    }

    public static function get_default_randomization_start_datetime() {
        $timezone = self::get_timezone();

        if ( function_exists( 'current_time' ) ) {
            $datetime = DateTime::createFromFormat( 'Y-m-d H:i:s', current_time( 'mysql' ), $timezone );
            if ( ! $datetime ) {
                $datetime = new DateTime( 'now', $timezone );
            }
        } else {
            $datetime = new DateTime( 'now', $timezone );
        }

        $datetime->modify( '-1 year' );
        $datetime->setTime( 0, 0, 0 );

        return $datetime->format( 'Y-m-d H:i:s' );
    }

    public static function get_default_randomization_end_datetime() {
        $timezone = self::get_timezone();

        if ( function_exists( 'current_time' ) ) {
            $datetime = DateTime::createFromFormat( 'Y-m-d H:i:s', current_time( 'mysql' ), $timezone );
            if ( ! $datetime ) {
                $datetime = new DateTime( 'now', $timezone );
            }
        } else {
            $datetime = new DateTime( 'now', $timezone );
        }

        $datetime->setTime( 23, 59, 59 );

        return $datetime->format( 'Y-m-d H:i:s' );
    }

}
