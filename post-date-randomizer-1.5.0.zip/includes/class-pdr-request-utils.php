<?php
/**
 * Safe scalar request helpers for Post Date Randomizer.
 *
 * @package PostDateRandomizer
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Centralizes safe scalar reads from request-like arrays.
 */
class PDR_Request_Utils {

    /**
     * Check whether a request-like source contains a key.
     *
     * @param mixed      $source Request-like source array.
     * @param string|int $key    Array key to check.
     * @return bool
     */
    public static function has_key( $source, $key ) {
        if ( ! is_array( $source ) || ( ! is_string( $key ) && ! is_int( $key ) ) ) {
            return false;
        }

        return array_key_exists( $key, $source );
    }

    /**
     * Read a scalar text value from a request-like source.
     *
     * @param mixed      $source  Request-like source array.
     * @param string|int $key     Array key to read.
     * @param string     $default Default value returned when unavailable.
     * @return string
     */
    public static function get_text( $source, $key, $default = '' ) {
        if ( ! self::has_key( $source, $key ) || ! is_scalar( $source[ $key ] ) ) {
            return $default;
        }

        return sanitize_text_field( wp_unslash( $source[ $key ] ) );
    }

    /**
     * Read a scalar key value from a request-like source.
     *
     * @param mixed      $source  Request-like source array.
     * @param string|int $key     Array key to read.
     * @param string     $default Default value returned when unavailable.
     * @return string
     */
    public static function get_key( $source, $key, $default = '' ) {
        if ( ! self::has_key( $source, $key ) || ! is_scalar( $source[ $key ] ) ) {
            return $default;
        }

        return sanitize_key( wp_unslash( $source[ $key ] ) );
    }
}
