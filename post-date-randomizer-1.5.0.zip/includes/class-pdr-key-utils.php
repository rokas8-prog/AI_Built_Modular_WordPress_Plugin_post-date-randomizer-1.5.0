<?php
/**
 * Key construction helpers for Post Date Randomizer.
 *
 * @package PostDateRandomizer
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Centralizes plugin job, lock, and notice key construction.
 */
class PDR_Key_Utils {

    /**
     * Sanitize a job/notice token for key construction.
     *
     * @param mixed $token Token value.
     * @return string
     */
    public static function sanitize_token( $token ) {
        return sanitize_key( (string) $token );
    }

    /**
     * Build the temporary job option key.
     *
     * @param mixed $token Job token.
     * @return string
     */
    public static function job_key( $token ) {
        return 'pdr_job_' . self::sanitize_token( $token );
    }

    /**
     * Build the temporary job lock transient key.
     *
     * @param mixed $token Job token.
     * @return string
     */
    public static function job_lock_key( $token ) {
        return 'pdr_job_lock_' . self::sanitize_token( $token );
    }

    /**
     * Build the run notice transient key.
     *
     * @param mixed $token Notice token.
     * @return string
     */
    public static function notice_key( $token ) {
        return 'pdr_notice_' . self::sanitize_token( $token );
    }

    /**
     * Build the completed job notice transient key.
     *
     * @param mixed $token Notice token.
     * @return string
     */
    public static function completed_job_notice_key( $token ) {
        return 'pdr_job_notice_' . self::sanitize_token( $token );
    }
}
