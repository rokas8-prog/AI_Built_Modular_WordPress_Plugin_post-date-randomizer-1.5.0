=== Post Date Randomizer ===
Plugin Name: Post Date Randomizer
Author: Rokas Golcas
Tags: post dates, comment dates, random dates, random post dates, random comment dates, bulk edit, schedule posts
Requires at least: 5.0
Stable tag: 1.5.0

Simple plugin that changes published post dates and/or approved comment dates to random dates within a specified time range. Processing runs in chunks and continues in the background using WP-Cron plus signed loopback requests, so larger jobs do not need to finish in one admin request.

== Description ==

Post Date Randomizer allows you to randomize dates for published posts of one selected public post type, approved comments, or both. You define the random date range in the "Date Randomizer" settings page in the WordPress dashboard.

The current architecture is built for chunked processing. When a run starts, the plugin stores a temporary job snapshot in a non-autoloaded WordPress option, processes a limited batch at a time, then continues through a signed loopback request and a scheduled WP-Cron event. A separate cleanup cron removes stale temporary jobs.

For posts, the plugin can optionally limit which published posts are affected by their current `post_date` value. These current-date filters apply to posts only. Comment randomization currently applies globally to all approved comments when the comment option is enabled; comment-specific filters are not available unless added in a future feature pass.

It comes with a settings page ("Date Randomizer" in the admin menu) where you can:

*   Select whether to randomize posts, comments, or both.
*   Set the start and end dates for the randomization range.
*   For posts, choose the specific public post type to affect.
*   For posts, optionally filter affected posts by their current `post_date` range.
*   For posts, optionally set the "Last Modified" date to match the new random "Published" date.

It supports past and future date ranges. Posts with dates randomized to the future may be scheduled by WordPress. Comment dates are updated to a random date within the selected range.

**Important:** This plugin performs irreversible changes to your post and comment dates. Always back up your database before use.

= Key Features: =

*   Chunked background processing for larger randomization jobs.
*   Background continuation through WP-Cron and signed non-blocking loopback requests.
*   Temporary job state stored in non-autoloaded options.
*   Daily cleanup cron for stale temporary jobs.
*   Randomize dates for published posts of one selected public post type and/or approved comments.
*   Choose to randomize only posts, only comments, or both.
*   Set a specific date and time range for the randomized dates.
*   Optionally filter affected posts by their current `post_date` range.
*   Optionally update the post "Last Modified" date to match the new "Published" date.
*   Auto-detects public post types for selection.
*   Simple settings interface integrated into the WordPress dashboard.

== Installation ==

1.  Download the plugin ZIP file.
2.  Log in to your WordPress admin area and go to Plugins > Add New.
3.  Click "Upload Plugin" and choose the ZIP file you downloaded.
4.  Activate the plugin through the 'Plugins' menu in WordPress.
5.  Go to the "Date Randomizer" menu item in your dashboard to configure the settings.
6.  **BACK UP YOUR DATABASE!**
7.  Configure your desired date range and options, click "Save Settings".
8.  Click the "Randomize Selected Item Dates Now" button to perform the randomization.

== Compatibility ==

Recommended for WordPress 5.0 and higher. Tested up to WordPress 6.7.

== Warning ==

The date changes performed by this plugin are **NOT REVERSIBLE** through the plugin interface. Please **backup your WordPress database** before you use this plugin. The authors are not responsible for any data loss. Use at your own risk.

== Upgrade Notice ==

Before updating, back up your site files and database.

== Changelog ==

= 1.5.0 - [30.04.2026] =
*   Release integrity: Unified plugin header, readme stable tag, and translation metadata version references to 1.5.0.
*   Documentation: Updated the readme to describe the current chunked processing, WP-Cron continuation, signed loopback continuation, temporary non-autoloaded job options, and stale job cleanup cron.
*   Documentation: Clarified that current-date filters apply to posts only, while approved comments are randomized globally when enabled.
*   Documentation: Removed current donation/support wording that no longer reflected the plugin documentation.

= 1.4.1 - [06.04.2025] =
*   Enhancement: Added donation links (readme header, settings page, plugin actions).
*   Code: Minor code cleanup and version bump.