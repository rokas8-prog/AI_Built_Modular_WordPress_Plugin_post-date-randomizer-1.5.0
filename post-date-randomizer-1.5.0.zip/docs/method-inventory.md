# Post Date Randomizer Method Ownership Inventory

Main plugin class: `PDR_Post_Date_Randomizer`

This inventory documents the current trait-based method ownership inside the main plugin class. Future edits should check this file before adding helpers, moving methods, or introducing new responsibilities so AI-assisted changes do not duplicate existing helpers or place logic in the wrong trait.

Service-class migration is a future architectural refactor. It must not be done casually or mixed into small bug-fix, hardening, lifecycle, documentation, or behavior-preservation patches.

## Main class composition

`PDR_Post_Date_Randomizer` currently uses these traits, in this order:

1. `PDR_Settings_Trait` — `includes/traits/class-pdr-settings-trait.php`
2. `PDR_Admin_Trait` — `includes/traits/class-pdr-admin-trait.php`
3. `PDR_Engine_Trait` — `includes/traits/class-pdr-engine-trait.php`
4. `PDR_Job_Storage_Trait` — `includes/traits/class-pdr-job-storage-trait.php`
5. `PDR_Job_Scheduler_Trait` — `includes/traits/class-pdr-job-scheduler-trait.php`
6. `PDR_Job_Notices_Trait` — `includes/traits/class-pdr-job-notices-trait.php`
7. `PDR_Job_Trait` — `includes/traits/class-pdr-job-trait.php`

## Class-owned methods

Defined directly in `post-date-randomizer.php` on `PDR_Post_Date_Randomizer`:

- `__construct()`
- `activate()`
- `deactivate()`
- `load_textdomain()`

Responsibility summary: WordPress bootstrap, hook registration, activation/deactivation lifecycle handling (activation schedules `pdr_randomizer_cleanup_jobs`; deactivation clears `pdr_randomizer_cleanup_jobs` and pending `pdr_randomizer_continue_job`), and textdomain loading.

## Trait method ownership

### `PDR_Settings_Trait`

File: `includes/traits/class-pdr-settings-trait.php`

Responsibility summary: Owns settings schema, defaults, settings validation/sanitization, registered post type discovery, and field rendering helpers used by the admin settings screen.

Methods:

- `get_default_datetime_from()`
- `get_default_datetime_to()`
- `get_settings_schema()`
- `get_setting_definition()`
- `get_setting_default()`
- `get_registered_public_post_types()`
- `is_valid_mysql_datetime()`
- `get_previous_or_default_value()`
- `get_raw_submitted_option_value()`
- `sanitize_datetime_for_save()`
- `get_sanitized_peer_datetime_value()`
- `validate_randomization_interval_on_save()`
- `validate_filter_interval_on_save()`
- `get_field_definition()`
- `render_checkbox_field_from_schema()`
- `render_datetime_field_from_schema()`
- `sanitize_checkbox()`
- `sanitize_post_type_option()`
- `sanitize_date_from_option()`
- `sanitize_date_to_option()`
- `sanitize_filter_date_from_option()`
- `sanitize_filter_date_to_option()`

### `PDR_Admin_Trait`

File: `includes/traits/class-pdr-admin-trait.php`

Responsibility summary: Owns admin menu registration, settings registration, admin request reads for the settings/run page, run-action routing, field callbacks, and settings page rendering.

Methods:

- `add_menu_page()`
- `register_settings()`
- `render_section_description()`
- `get_run_request_page()`
- `get_run_request_trigger()`
- `get_run_request_job_token()`
- `get_run_notice_token()`
- `maybe_handle_run_action()`
- `render_schema_field()`
- `field_post_type()`
- `render_settings_page()`

### `PDR_Engine_Trait`

File: `includes/traits/class-pdr-engine-trait.php`

Responsibility summary: Owns the randomization trigger flow, nonce reading, job start/finalization, cron/loopback job entry points, per-chunk token processing, and single post/comment date updates.

Methods:

- `get_run_nonce_value()`
- `handle_randomize_request()`
- `get_randomizer_page_url()`
- `build_randomizer_result_notice_payload()`
- `finalize_randomizer_job()`
- `process_randomizer_job_token_chunk()`
- `handle_randomizer_job_cron()`
- `handle_randomizer_job_loopback()`
- `randomize_single_post()`
- `randomize_single_comment()`

### `PDR_Job_Storage_Trait`

File: `includes/traits/class-pdr-job-storage-trait.php`

Responsibility summary: Owns job token creation, temporary job option keys, persistence/loading/saving/deletion, initial job snapshots, job state normalization, and stale job discovery.

Methods:

- `get_job_transient_key()`
- `get_job_option_key()`
- `create_job_token()`
- `get_randomizer_job_storage_timestamp()`
- `prepare_randomizer_job_for_storage()`
- `persist_randomizer_job_option()`
- `start_randomizer_job()`
- `load_randomizer_job()`
- `save_randomizer_job()`
- `delete_randomizer_job()`
- `build_job_snapshot()`
- `normalize_randomizer_job_state()`
- `get_randomizer_job_stale_age()`
- `get_randomizer_job_updated_timestamp()`
- `get_stale_randomizer_job_tokens()`

### `PDR_Job_Scheduler_Trait`

File: `includes/traits/class-pdr-job-scheduler-trait.php`

Responsibility summary: Owns job lock keys/payloads, lock acquire/release behavior, continuation cron scheduling, signed loopback action/signature helpers, loopback dispatch, and continuation cron clearing.

Methods:

- `get_job_lock_timeout()`
- `get_job_lock_transient_key()`
- `get_job_lock_option_key()`
- `get_randomizer_job_lock_payload()`
- `is_randomizer_job_lock_expired()`
- `update_randomizer_job_lock_option()`
- `acquire_randomizer_job_lock()`
- `release_randomizer_job_lock()`
- `schedule_randomizer_job_cron()`
- `get_randomizer_job_loopback_action()`
- `get_randomizer_job_loopback_signature()`
- `is_valid_randomizer_job_loopback_signature()`
- `dispatch_randomizer_job_loopback()`
- `clear_randomizer_job_cron()`

### `PDR_Job_Notices_Trait`

File: `includes/traits/class-pdr-job-notices-trait.php`

Responsibility summary: Owns transient keys and helpers for run notices and completed-job notices, including payload storage, consumption, normalization, legacy notice conversion, and admin notice rendering.

Methods:

- `get_notice_transient_key()`
- `get_completed_job_notice_transient_key()`
- `store_completed_randomizer_job_notice_token()`
- `consume_completed_randomizer_job_notice_token()`
- `build_run_notice_payload()`
- `store_run_notice_payloads()`
- `consume_run_notice_payloads()`
- `normalize_run_notice_payloads()`
- `convert_legacy_run_notice_html_to_payloads()`
- `render_run_notice_payloads()`

### `PDR_Job_Trait`

File: `includes/traits/class-pdr-job-trait.php`

Responsibility summary: Owns chunk-level job execution, streaming batch processing, streaming cursor/progress updates, post/comment batch ID fetching, SQL identifier allowlisting for streaming fetches, and cleanup cron handling for stale jobs.

Methods:

- `get_job_batch_size()`
- `process_randomizer_job_chunk()`
- `process_streaming_job_batch()`
- `apply_streaming_job_batch_result()`
- `fetch_streaming_job_batch_ids()`
- `fetch_next_post_job_batch_ids()`
- `fetch_next_comment_job_batch_ids()`
- `handle_randomizer_job_cleanup_cron()`


## Legacy compatibility bridges

These bridges are intentionally narrow compatibility layers, not duplicate active architecture:

- **Transient job fallback** in `PDR_Job_Storage_Trait::load_randomizer_job()` migrates or finishes older jobs that were stored in transients before current jobs moved to non-autoloaded options. Do not expand this fallback; future removal requires a separate compatibility decision.
- **Legacy HTML notice conversion** in `PDR_Job_Notices_Trait::convert_legacy_run_notice_html_to_payloads()` normalizes old HTML notice payloads into the current structured payload array format. Do not use it for new notice formats.

## Future edit warning

Before adding any new helper, search this inventory and the full plugin source for existing ownership. Do not add duplicate request readers, date helpers, job storage helpers, lock helpers, notice helpers, SQL batch helpers, or admin field helpers without first confirming that the responsibility is not already owned by an existing trait.

If a future service-class migration is needed, it should be planned as a dedicated architectural refactor with explicit acceptance criteria. Do not partially migrate traits into service classes as part of unrelated fixes.
