# Post Date Randomizer Service-Class Migration Plan

This document is a planning aid only. It describes a future safe migration away from the current trait-heavy architecture without changing runtime behavior in the current release.

## 1. Current architecture summary

### Main plugin class

The plugin currently has one main runtime class:

- `PDR_Post_Date_Randomizer` in `post-date-randomizer.php`

The main class is responsible for bootstrap and lifecycle wiring:

- `__construct()` registers WordPress hooks.
- `activate()` schedules the daily cleanup cron hook.
- `deactivate()` clears cleanup and continuation cron hooks.
- `load_textdomain()` loads the `post-date-randomizer` text domain.

The main class also defines the core constants that must remain stable during any migration:

- `OPTION_GROUP` = `pdr_options_group`
- `SETTINGS_PAGE` = `pdr_settings_page_slug`
- `JOB_CRON_HOOK` = `pdr_randomizer_continue_job`
- `JOB_CLEANUP_CRON_HOOK` = `pdr_randomizer_cleanup_jobs`

### Current traits

`PDR_Post_Date_Randomizer` currently composes behavior through these traits:

- `PDR_Settings_Trait` — `includes/traits/class-pdr-settings-trait.php`
- `PDR_Admin_Trait` — `includes/traits/class-pdr-admin-trait.php`
- `PDR_Engine_Trait` — `includes/traits/class-pdr-engine-trait.php`
- `PDR_Job_Storage_Trait` — `includes/traits/class-pdr-job-storage-trait.php`
- `PDR_Job_Scheduler_Trait` — `includes/traits/class-pdr-job-scheduler-trait.php`
- `PDR_Job_Notices_Trait` — `includes/traits/class-pdr-job-notices-trait.php`
- `PDR_Job_Trait` — `includes/traits/class-pdr-job-trait.php`

### Utility classes currently available

The plugin already has utility classes that should continue to be reused instead of duplicated:

- `PDR_Date_Utils` — `includes/class-pdr-date-utils.php`
  - Timezone handling.
  - MySQL datetime formatting and validation.
  - Timestamp parsing.
  - Datetime comparison.
  - Default randomization range generation.
- `PDR_Request_Utils` — `includes/class-pdr-request-utils.php`
  - Safe scalar reads from request-like arrays.
  - Sanitized text and key reads.
- `PDR_Key_Utils` — `includes/class-pdr-key-utils.php`
  - Job option key construction.
  - Job lock key construction.
  - Run notice key construction.
  - Completed-job notice key construction.

## 2. Proposed future service classes

A future migration may introduce these service classes:

- `PDR_Admin_Page`
- `PDR_Settings`
- `PDR_Background_Job_Runner`
- `PDR_Job_Storage`
- `PDR_Job_Scheduler`
- `PDR_Job_Notices`

The goal is not to change behavior. The goal is to move responsibility boundaries from traits into explicit service objects while preserving the existing public WordPress integration surface.

## 3. Proposed service ownership map

### `PDR_Admin_Page`

#### Responsibility

Own the admin menu page, settings-page rendering, admin run-action request routing, and admin request readers.

#### Methods it would own

| Future method | Current method | Current location |
|---|---|---|
| `add_menu_page()` | `add_menu_page()` | `includes/traits/class-pdr-admin-trait.php` |
| `render_section_description()` | `render_section_description()` | `includes/traits/class-pdr-admin-trait.php` |
| `get_run_request_page()` | `get_run_request_page()` | `includes/traits/class-pdr-admin-trait.php` |
| `get_run_request_trigger()` | `get_run_request_trigger()` | `includes/traits/class-pdr-admin-trait.php` |
| `get_run_request_job_token()` | `get_run_request_job_token()` | `includes/traits/class-pdr-admin-trait.php` |
| `get_run_notice_token()` | `get_run_notice_token()` | `includes/traits/class-pdr-admin-trait.php` |
| `maybe_handle_run_action()` | `maybe_handle_run_action()` | `includes/traits/class-pdr-admin-trait.php` |
| `render_settings_page()` | `render_settings_page()` | `includes/traits/class-pdr-admin-trait.php` |

`register_settings()`, `render_schema_field()`, and `field_post_type()` are currently in `PDR_Admin_Trait`, but they are settings-oriented. In a service migration, they should either move to `PDR_Settings` or remain as compatibility wrappers on `PDR_Admin_Page` that delegate to `PDR_Settings`.

#### Dependencies it would need

- `PDR_Settings` for settings registration and field rendering.
- `PDR_Background_Job_Runner` for run-action start and continuation processing.
- `PDR_Job_Notices` for notice storage, consumption, normalization, and rendering.
- `PDR_Request_Utils` for request reads.
- WordPress admin functions such as `add_menu_page()`, `current_user_can()`, `wp_die()`, `wp_safe_redirect()`, `admin_url()`, and `add_query_arg()`.
- Main plugin constants or a small immutable config object for `OPTION_GROUP`, `SETTINGS_PAGE`, `JOB_CRON_HOOK`, and `JOB_CLEANUP_CRON_HOOK`.

#### Hooks that must remain unchanged

- `admin_menu` must continue to reach the same admin page registration behavior.
- `admin_init` must continue to trigger run-action handling.
- The admin page slug must remain `pdr_settings_page_slug`.
- The run form request names must remain unchanged:
  - `pdr_run_randomize`
  - `pdr_run_nonce`
- The run progress and notice query arguments must remain unchanged:
  - `pdr_run_job`
  - `pdr_notice`

If the hook callback is moved to the service directly, the main class should keep compatibility wrappers first, then delegate to the service. Do not break code that expects the main class methods to exist.

### `PDR_Settings`

#### Responsibility

Own the settings schema, option defaults, option sanitization, validation, registered post type discovery, and settings field rendering.

#### Methods it would own

| Future method | Current method | Current location |
|---|---|---|
| `register_settings()` | `register_settings()` | `includes/traits/class-pdr-admin-trait.php` |
| `render_schema_field()` | `render_schema_field()` | `includes/traits/class-pdr-admin-trait.php` |
| `field_post_type()` | `field_post_type()` | `includes/traits/class-pdr-admin-trait.php` |
| `get_default_datetime_from()` | `get_default_datetime_from()` | `includes/traits/class-pdr-settings-trait.php` |
| `get_default_datetime_to()` | `get_default_datetime_to()` | `includes/traits/class-pdr-settings-trait.php` |
| `get_settings_schema()` | `get_settings_schema()` | `includes/traits/class-pdr-settings-trait.php` |
| `get_setting_definition()` | `get_setting_definition()` | `includes/traits/class-pdr-settings-trait.php` |
| `get_setting_default()` | `get_setting_default()` | `includes/traits/class-pdr-settings-trait.php` |
| `get_registered_public_post_types()` | `get_registered_public_post_types()` | `includes/traits/class-pdr-settings-trait.php` |
| `is_valid_mysql_datetime()` | `is_valid_mysql_datetime()` | `includes/traits/class-pdr-settings-trait.php` |
| `get_previous_or_default_value()` | `get_previous_or_default_value()` | `includes/traits/class-pdr-settings-trait.php` |
| `get_raw_submitted_option_value()` | `get_raw_submitted_option_value()` | `includes/traits/class-pdr-settings-trait.php` |
| `sanitize_datetime_for_save()` | `sanitize_datetime_for_save()` | `includes/traits/class-pdr-settings-trait.php` |
| `get_sanitized_peer_datetime_value()` | `get_sanitized_peer_datetime_value()` | `includes/traits/class-pdr-settings-trait.php` |
| `validate_randomization_interval_on_save()` | `validate_randomization_interval_on_save()` | `includes/traits/class-pdr-settings-trait.php` |
| `validate_filter_interval_on_save()` | `validate_filter_interval_on_save()` | `includes/traits/class-pdr-settings-trait.php` |
| `get_field_definition()` | `get_field_definition()` | `includes/traits/class-pdr-settings-trait.php` |
| `render_checkbox_field_from_schema()` | `render_checkbox_field_from_schema()` | `includes/traits/class-pdr-settings-trait.php` |
| `render_datetime_field_from_schema()` | `render_datetime_field_from_schema()` | `includes/traits/class-pdr-settings-trait.php` |
| `sanitize_checkbox()` | `sanitize_checkbox()` | `includes/traits/class-pdr-settings-trait.php` |
| `sanitize_post_type_option()` | `sanitize_post_type_option()` | `includes/traits/class-pdr-settings-trait.php` |
| `sanitize_date_from_option()` | `sanitize_date_from_option()` | `includes/traits/class-pdr-settings-trait.php` |
| `sanitize_date_to_option()` | `sanitize_date_to_option()` | `includes/traits/class-pdr-settings-trait.php` |
| `sanitize_filter_date_from_option()` | `sanitize_filter_date_from_option()` | `includes/traits/class-pdr-settings-trait.php` |
| `sanitize_filter_date_to_option()` | `sanitize_filter_date_to_option()` | `includes/traits/class-pdr-settings-trait.php` |

#### Dependencies it would need

- `PDR_Date_Utils` for datetime validation, parsing, comparison, and defaults.
- `PDR_Request_Utils` only if request reads are moved out of raw `$_POST` access in a future patch.
- WordPress Settings API functions such as `register_setting()`, `add_settings_section()`, `add_settings_field()`, `add_settings_error()`, `settings_fields()`, `do_settings_sections()`, and `submit_button()`.
- WordPress option and post type functions such as `get_option()` and `get_post_types()`.
- Main plugin constants or config values for `OPTION_GROUP` and `SETTINGS_PAGE`.

#### Hooks that must remain unchanged

- `admin_init` must continue to register the same settings.
- Settings group must remain `pdr_options_group`.
- Settings page slug must remain `pdr_settings_page_slug`.
- Settings section ID must remain `pdr_main_section` unless a separate UI migration explicitly changes it.
- Option names must remain unchanged:
  - `pdr_randomize_posts`
  - `pdr_randomize_comments`
  - `pdr_post_type`
  - `pdr_set_modified_date`
  - `pdr_date_from`
  - `pdr_date_to`
  - `pdr_filter_date_from`
  - `pdr_filter_date_to`
- Sanitizer callback method names must remain reachable through the same public callback names until compatibility wrappers are intentionally removed in a separate major refactor.

### `PDR_Background_Job_Runner`

#### Responsibility

Own the randomization run flow, job continuation entry points, chunk processing orchestration, post/comment date updates, and finalization coordination.

#### Methods it would own

| Future method | Current method | Current location |
|---|---|---|
| `get_run_nonce_value()` | `get_run_nonce_value()` | `includes/traits/class-pdr-engine-trait.php` |
| `handle_randomize_request()` | `handle_randomize_request()` | `includes/traits/class-pdr-engine-trait.php` |
| `get_randomizer_page_url()` | `get_randomizer_page_url()` | `includes/traits/class-pdr-engine-trait.php` |
| `build_randomizer_result_notice_payload()` | `build_randomizer_result_notice_payload()` | `includes/traits/class-pdr-engine-trait.php` |
| `finalize_randomizer_job()` | `finalize_randomizer_job()` | `includes/traits/class-pdr-engine-trait.php` |
| `process_randomizer_job_token_chunk()` | `process_randomizer_job_token_chunk()` | `includes/traits/class-pdr-engine-trait.php` |
| `handle_randomizer_job_cron()` | `handle_randomizer_job_cron()` | `includes/traits/class-pdr-engine-trait.php` |
| `handle_randomizer_job_loopback()` | `handle_randomizer_job_loopback()` | `includes/traits/class-pdr-engine-trait.php` |
| `randomize_single_post()` | `randomize_single_post()` | `includes/traits/class-pdr-engine-trait.php` |
| `randomize_single_comment()` | `randomize_single_comment()` | `includes/traits/class-pdr-engine-trait.php` |
| `get_job_batch_size()` | `get_job_batch_size()` | `includes/traits/class-pdr-job-trait.php` |
| `process_randomizer_job_chunk()` | `process_randomizer_job_chunk()` | `includes/traits/class-pdr-job-trait.php` |
| `process_streaming_job_batch()` | `process_streaming_job_batch()` | `includes/traits/class-pdr-job-trait.php` |
| `apply_streaming_job_batch_result()` | `apply_streaming_job_batch_result()` | `includes/traits/class-pdr-job-trait.php` |
| `fetch_streaming_job_batch_ids()` | `fetch_streaming_job_batch_ids()` | `includes/traits/class-pdr-job-trait.php` |
| `fetch_next_post_job_batch_ids()` | `fetch_next_post_job_batch_ids()` | `includes/traits/class-pdr-job-trait.php` |
| `fetch_next_comment_job_batch_ids()` | `fetch_next_comment_job_batch_ids()` | `includes/traits/class-pdr-job-trait.php` |

`handle_randomizer_job_cleanup_cron()` is currently in `PDR_Job_Trait`, but it is cleanup orchestration rather than per-chunk execution. In a service migration it should be owned by `PDR_Job_Scheduler` or a small cleanup method that delegates to `PDR_Job_Storage`, `PDR_Job_Scheduler`, and `PDR_Job_Notices`.

#### Dependencies it would need

- `PDR_Settings` for defaults and option-related reads.
- `PDR_Job_Storage` for job creation, loading, saving, deletion, and state normalization.
- `PDR_Job_Scheduler` for locks, cron scheduling, loopback dispatch, signature validation, and cron clearing.
- `PDR_Job_Notices` for result payloads and completed-job notice tokens.
- `PDR_Date_Utils` for timestamp parsing and date formatting.
- `PDR_Request_Utils` for nonce, loopback token, and signature reads.
- `$wpdb` for streaming batch ID queries.
- WordPress functions such as `current_user_can()`, `wp_die()`, `wp_verify_nonce()`, `get_option()`, `wp_safe_redirect()`, `status_header()`, `wp_update_post()`, `wp_update_comment()`, and `get_gmt_from_date()`.

#### Hooks that must remain unchanged

- `admin_init` run-action behavior must still reach `handle_randomize_request()` through the same admin form flow.
- Cron continuation hook must remain `pdr_randomizer_continue_job`.
- Loopback action route must remain `admin-post.php?action=pdr_continue_job`.
- Both loopback hooks must remain functionally available:
  - `admin_post_pdr_continue_job`
  - `admin_post_nopriv_pdr_continue_job`
- Loopback request body keys must remain unchanged:
  - `action`
  - `pdr_job_token`
  - `pdr_job_sig`
- The HMAC signature purpose string must not change unless a separate compatibility migration is designed.
- The randomizer result redirect query arguments must remain unchanged:
  - `pdr_run_job`
  - `pdr_notice`

### `PDR_Job_Storage`

#### Responsibility

Own job token creation, job key generation, non-autoloaded option persistence, legacy transient compatibility, job snapshot construction, state normalization, and stale job discovery.

#### Methods it would own

| Future method | Current method | Current location |
|---|---|---|
| `get_job_transient_key()` | `get_job_transient_key()` | `includes/traits/class-pdr-job-storage-trait.php` |
| `get_job_option_key()` | `get_job_option_key()` | `includes/traits/class-pdr-job-storage-trait.php` |
| `create_job_token()` | `create_job_token()` | `includes/traits/class-pdr-job-storage-trait.php` |
| `get_randomizer_job_storage_timestamp()` | `get_randomizer_job_storage_timestamp()` | `includes/traits/class-pdr-job-storage-trait.php` |
| `prepare_randomizer_job_for_storage()` | `prepare_randomizer_job_for_storage()` | `includes/traits/class-pdr-job-storage-trait.php` |
| `persist_randomizer_job_option()` | `persist_randomizer_job_option()` | `includes/traits/class-pdr-job-storage-trait.php` |
| `start_randomizer_job()` | `start_randomizer_job()` | `includes/traits/class-pdr-job-storage-trait.php` |
| `load_randomizer_job()` | `load_randomizer_job()` | `includes/traits/class-pdr-job-storage-trait.php` |
| `save_randomizer_job()` | `save_randomizer_job()` | `includes/traits/class-pdr-job-storage-trait.php` |
| `delete_randomizer_job()` | `delete_randomizer_job()` | `includes/traits/class-pdr-job-storage-trait.php` |
| `build_job_snapshot()` | `build_job_snapshot()` | `includes/traits/class-pdr-job-storage-trait.php` |
| `normalize_randomizer_job_state()` | `normalize_randomizer_job_state()` | `includes/traits/class-pdr-job-storage-trait.php` |
| `get_randomizer_job_stale_age()` | `get_randomizer_job_stale_age()` | `includes/traits/class-pdr-job-storage-trait.php` |
| `get_randomizer_job_updated_timestamp()` | `get_randomizer_job_updated_timestamp()` | `includes/traits/class-pdr-job-storage-trait.php` |
| `get_stale_randomizer_job_tokens()` | `get_stale_randomizer_job_tokens()` | `includes/traits/class-pdr-job-storage-trait.php` |

#### Dependencies it would need

- `PDR_Key_Utils` for job key construction.
- `PDR_Date_Utils` for stale-job timestamp parsing.
- `PDR_Settings` or a settings/options adapter for defaults used by `build_job_snapshot()`.
- `$wpdb` for stale job discovery in the options table.
- WordPress functions such as `wp_generate_password()`, `current_time()`, `get_option()`, `add_option()`, `update_option()`, `delete_option()`, `get_transient()`, `delete_transient()`, `maybe_unserialize()`, and `get_current_user_id()`.

#### Hooks and data names that must remain unchanged

- Job option prefix must remain `pdr_job_`.
- Legacy transient key compatibility must remain `pdr_job_` while the bridge is supported.
- Jobs must remain stored as non-autoloaded options unless a separate storage migration is explicitly designed.
- Current job array keys must remain stable:
  - `randomize_posts`
  - `randomize_comments`
  - `post_type`
  - `set_modified_date`
  - `date_from`
  - `date_to`
  - `filter_date_from`
  - `filter_date_to`
  - `phase`
  - `last_post_id`
  - `last_comment_id`
  - `posts_processed`
  - `comments_processed`
  - `created_at`
  - `updated_at`
  - `started_by_user`
  - `done`
- Legacy queue/cursor compatibility keys must not be removed without a separate compatibility decision:
  - `post_queue`
  - `comment_queue`
  - `post_total`
  - `comment_total`
  - `post_cursor`
  - `comment_cursor`

### `PDR_Job_Scheduler`

#### Responsibility

Own job locks, cron scheduling, loopback action metadata, loopback signature generation/validation, loopback dispatch, cron clearing, and stale-job cleanup orchestration.

#### Methods it would own

| Future method | Current method | Current location |
|---|---|---|
| `get_job_lock_timeout()` | `get_job_lock_timeout()` | `includes/traits/class-pdr-job-scheduler-trait.php` |
| `get_job_lock_transient_key()` | `get_job_lock_transient_key()` | `includes/traits/class-pdr-job-scheduler-trait.php` |
| `get_job_lock_option_key()` | `get_job_lock_option_key()` | `includes/traits/class-pdr-job-scheduler-trait.php` |
| `get_randomizer_job_lock_payload()` | `get_randomizer_job_lock_payload()` | `includes/traits/class-pdr-job-scheduler-trait.php` |
| `is_randomizer_job_lock_expired()` | `is_randomizer_job_lock_expired()` | `includes/traits/class-pdr-job-scheduler-trait.php` |
| `update_randomizer_job_lock_option()` | `update_randomizer_job_lock_option()` | `includes/traits/class-pdr-job-scheduler-trait.php` |
| `acquire_randomizer_job_lock()` | `acquire_randomizer_job_lock()` | `includes/traits/class-pdr-job-scheduler-trait.php` |
| `release_randomizer_job_lock()` | `release_randomizer_job_lock()` | `includes/traits/class-pdr-job-scheduler-trait.php` |
| `schedule_randomizer_job_cron()` | `schedule_randomizer_job_cron()` | `includes/traits/class-pdr-job-scheduler-trait.php` |
| `get_randomizer_job_loopback_action()` | `get_randomizer_job_loopback_action()` | `includes/traits/class-pdr-job-scheduler-trait.php` |
| `get_randomizer_job_loopback_signature()` | `get_randomizer_job_loopback_signature()` | `includes/traits/class-pdr-job-scheduler-trait.php` |
| `is_valid_randomizer_job_loopback_signature()` | `is_valid_randomizer_job_loopback_signature()` | `includes/traits/class-pdr-job-scheduler-trait.php` |
| `dispatch_randomizer_job_loopback()` | `dispatch_randomizer_job_loopback()` | `includes/traits/class-pdr-job-scheduler-trait.php` |
| `clear_randomizer_job_cron()` | `clear_randomizer_job_cron()` | `includes/traits/class-pdr-job-scheduler-trait.php` |
| `handle_randomizer_job_cleanup_cron()` | `handle_randomizer_job_cleanup_cron()` | `includes/traits/class-pdr-job-trait.php` |

#### Dependencies it would need

- `PDR_Key_Utils` for lock key construction.
- `PDR_Job_Storage` for stale token discovery and job deletion during cleanup.
- `PDR_Background_Job_Runner` only for continuation entry-point coordination, not for lock internals.
- `$wpdb` for atomic lock option updates.
- WordPress functions such as `add_option()`, `get_option()`, `delete_option()`, `get_transient()`, `delete_transient()`, `wp_cache_delete()`, `wp_next_scheduled()`, `wp_schedule_single_event()`, `wp_clear_scheduled_hook()`, `wp_remote_post()`, `admin_url()`, `apply_filters()`, `wp_salt()`, and `wp_unschedule_hook()`.

#### Hooks that must remain unchanged

- Continuation cron hook must remain `pdr_randomizer_continue_job`.
- Cleanup cron hook must remain `pdr_randomizer_cleanup_jobs`.
- Cleanup recurrence must remain daily unless changed in a separate scheduling patch.
- Lock option/transient prefix must remain `pdr_job_lock_`.
- Loopback action must remain `pdr_continue_job`.
- Loopback endpoint must remain `admin-post.php`.
- Loopback request keys must remain `pdr_job_token` and `pdr_job_sig`.
- The loopback corridor must remain scoped to signed background continuation only.

### `PDR_Job_Notices`

#### Responsibility

Own run notice and completed-job notice key construction, notice payload storage, notice payload consumption, notice normalization, legacy HTML notice conversion, and notice rendering.

#### Methods it would own

| Future method | Current method | Current location |
|---|---|---|
| `get_notice_transient_key()` | `get_notice_transient_key()` | `includes/traits/class-pdr-job-notices-trait.php` |
| `get_completed_job_notice_transient_key()` | `get_completed_job_notice_transient_key()` | `includes/traits/class-pdr-job-notices-trait.php` |
| `store_completed_randomizer_job_notice_token()` | `store_completed_randomizer_job_notice_token()` | `includes/traits/class-pdr-job-notices-trait.php` |
| `consume_completed_randomizer_job_notice_token()` | `consume_completed_randomizer_job_notice_token()` | `includes/traits/class-pdr-job-notices-trait.php` |
| `build_run_notice_payload()` | `build_run_notice_payload()` | `includes/traits/class-pdr-job-notices-trait.php` |
| `store_run_notice_payloads()` | `store_run_notice_payloads()` | `includes/traits/class-pdr-job-notices-trait.php` |
| `consume_run_notice_payloads()` | `consume_run_notice_payloads()` | `includes/traits/class-pdr-job-notices-trait.php` |
| `normalize_run_notice_payloads()` | `normalize_run_notice_payloads()` | `includes/traits/class-pdr-job-notices-trait.php` |
| `convert_legacy_run_notice_html_to_payloads()` | `convert_legacy_run_notice_html_to_payloads()` | `includes/traits/class-pdr-job-notices-trait.php` |
| `render_run_notice_payloads()` | `render_run_notice_payloads()` | `includes/traits/class-pdr-job-notices-trait.php` |

#### Dependencies it would need

- `PDR_Key_Utils` for notice key construction.
- `PDR_Job_Storage` or a token generator dependency for notice token creation. Current code reuses `create_job_token()`.
- WordPress functions such as `set_transient()`, `get_transient()`, `delete_transient()`, `sanitize_key()`, `wp_strip_all_tags()`, `esc_attr()`, and `esc_html()`.

#### Hooks and data names that must remain unchanged

- Run notice transient prefix must remain `pdr_notice_`.
- Completed-job notice transient prefix must remain `pdr_job_notice_`.
- Notice query argument must remain `pdr_notice`.
- Completed job query argument must remain `pdr_run_job`.
- Notice payload array keys must remain:
  - `type`
  - `message`
- Allowed notice types must remain compatible with current admin CSS classes:
  - `success`
  - `warning`
  - `error`
- Legacy HTML notice conversion must remain until a separate compatibility decision removes it.

## 4. Future migration sequence

A safe migration should be split into small patches. A recommended order is:

1. Add service class files with no runtime usage, if needed.
2. Migrate `PDR_Job_Notices` first because it has a small, contained surface.
3. Migrate `PDR_Job_Storage` next, preserving all job array keys and legacy bridges.
4. Migrate `PDR_Job_Scheduler`, preserving cron hooks, lock keys, and loopback action/signature behavior.
5. Migrate `PDR_Settings`, preserving option keys, sanitizer callback reachability, and Settings API registration behavior.
6. Migrate `PDR_Background_Job_Runner`, preserving cron callbacks and loopback callbacks through wrappers.
7. Migrate `PDR_Admin_Page` last, preserving the admin menu slug, form fields, redirects, and notice behavior.
8. Remove traits only after every public callback has a compatibility wrapper or a documented replacement.

## 5. Safety rules for future migration

- Migrate one service at a time.
- Preserve public hook callbacks.
- Preserve option keys.
- Preserve cron hook names.
- Preserve route/action names.
- Preserve job array keys.
- Preserve admin UI behavior.
- Add compatibility wrappers if public methods are moved.
- Keep `post-date-randomizer` as the text domain.
- Keep `pdr_options_group` as the option group.
- Keep `pdr_settings_page_slug` as the admin page slug.
- Keep `pdr_randomizer_continue_job` as the continuation cron hook.
- Keep `pdr_randomizer_cleanup_jobs` as the cleanup cron hook.
- Keep `pdr_continue_job` as the signed loopback action.
- Keep the signed loopback endpoint restricted to job continuation only.
- Keep existing request keys and query arguments unless a separate compatibility layer is planned.
- Do not change runtime behavior in the same patch that moves architecture.
- Do not mix service migration with localization, security hardening, UI changes, cron changes, route changes, or settings changes.
- Before moving any method, search the full plugin for direct method references and callback registrations.
- After moving any public callback, leave a main-class wrapper with the same method name until a separate compatibility-removal release.

## 6. Explicit warning

Do not convert traits to service classes in one large patch.

A broad trait-to-service conversion would risk breaking WordPress callbacks, option sanitizers, cron continuation, loopback processing, job storage compatibility, admin redirects, and completed-job notices at the same time. The migration should be performed only as a sequence of narrow, testable, behavior-preserving patches.
