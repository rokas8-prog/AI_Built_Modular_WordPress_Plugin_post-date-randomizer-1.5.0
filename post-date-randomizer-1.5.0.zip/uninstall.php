<?php
/**
 * Plugin uninstall cleanup.
 *
 * Removes only temporary Post Date Randomizer background-processing data.
 *
 * @package Post_Date_Randomizer
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

wp_unschedule_hook( 'pdr_randomizer_continue_job' );
wp_unschedule_hook( 'pdr_randomizer_cleanup_jobs' );

global $wpdb;

$prefixes = array(
	'pdr_job_',
	'pdr_job_lock_',
	'_transient_pdr_notice_',
	'_transient_timeout_pdr_notice_',
	'_transient_pdr_job_notice_',
	'_transient_timeout_pdr_job_notice_',
	'_transient_pdr_job_',
	'_transient_timeout_pdr_job_',
	'_transient_pdr_job_lock_',
	'_transient_timeout_pdr_job_lock_',
);

foreach ( $prefixes as $prefix ) {
	$wpdb->query(
		$wpdb->prepare(
			"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
			$wpdb->esc_like( $prefix ) . '%'
		)
	);
}
