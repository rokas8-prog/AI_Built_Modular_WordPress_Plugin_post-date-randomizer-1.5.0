<?php
/*
Plugin Name: Post Date Randomizer
Description: Randomizes post and/or comment dates in a user-defined date range. Modified to use options for all behaviors and to filter which posts are affected by current date.
Version:     1.5.0
Author:      Rokas Golcas
Text Domain: post-date-randomizer
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once plugin_dir_path( __FILE__ ) . 'includes/class-pdr-date-utils.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/class-pdr-request-utils.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/class-pdr-key-utils.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/traits/class-pdr-settings-trait.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/traits/class-pdr-admin-trait.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/traits/class-pdr-engine-trait.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/traits/class-pdr-job-storage-trait.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/traits/class-pdr-job-scheduler-trait.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/traits/class-pdr-job-notices-trait.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/traits/class-pdr-job-trait.php';

class PDR_Post_Date_Randomizer {

    use PDR_Settings_Trait;
    use PDR_Admin_Trait;
    use PDR_Engine_Trait;
    use PDR_Job_Storage_Trait;
    use PDR_Job_Scheduler_Trait;
    use PDR_Job_Notices_Trait;
    use PDR_Job_Trait;

    const OPTION_GROUP          = 'pdr_options_group';
    const SETTINGS_PAGE         = 'pdr_settings_page_slug';
    const JOB_CRON_HOOK         = 'pdr_randomizer_continue_job';
    const JOB_CLEANUP_CRON_HOOK = 'pdr_randomizer_cleanup_jobs';

    protected $run_action_notices = '';

    public function __construct() {
        add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );
        add_action( 'admin_menu', array( $this, 'add_menu_page' ) );
        add_action( 'admin_init', array( $this, 'register_settings' ) );
        add_action( 'admin_init', array( $this, 'maybe_handle_run_action' ) );
        add_action( self::JOB_CRON_HOOK, array( $this, 'handle_randomizer_job_cron' ), 10, 1 );
        add_action( self::JOB_CLEANUP_CRON_HOOK, array( $this, 'handle_randomizer_job_cleanup_cron' ) );
        /*
         * Signed loopback corridor: the nopriv endpoint is intentionally unauthenticated
         * only for non-blocking local/background continuation. It must accept only a
         * valid signed job token and must not perform unrelated actions without a
         * security review.
         */
        add_action( 'admin_post_pdr_continue_job', array( $this, 'handle_randomizer_job_loopback' ) );
        add_action( 'admin_post_nopriv_pdr_continue_job', array( $this, 'handle_randomizer_job_loopback' ) );
    }

    public static function activate() {
        if ( false !== wp_next_scheduled( self::JOB_CLEANUP_CRON_HOOK ) ) {
            return;
        }

        wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::JOB_CLEANUP_CRON_HOOK );
    }

    public static function deactivate() {
        wp_clear_scheduled_hook( self::JOB_CLEANUP_CRON_HOOK );

        if ( function_exists( 'wp_unschedule_hook' ) ) {
            wp_unschedule_hook( self::JOB_CRON_HOOK );
        }
    }

    public function load_textdomain() {
        load_plugin_textdomain( 'post-date-randomizer', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
    }

}

register_activation_hook( __FILE__, array( 'PDR_Post_Date_Randomizer', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'PDR_Post_Date_Randomizer', 'deactivate' ) );

new PDR_Post_Date_Randomizer();